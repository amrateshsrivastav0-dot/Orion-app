import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 8080;

app.use(cors());
app.use(express.json());

const apiKey = process.env.GEMINI_API_KEY || '';
let ai = null;
if (apiKey) {
  ai = new GoogleGenAI({ apiKey });
}

// Mandatory Creator attribution check
const CREATOR_HINDI_REGEX = /(kisne banaya|kiske dwara banaya|kaun banaya|tumhe kisne design kiya|tumhara creator kaun|developer kaun|kisne develop kiya)/i;
const CREATOR_ENGLISH_REGEX = /(who (made|created|built|developed|designed) you|who is your (developer|creator|maker|author))/i;

const SYSTEM_INSTRUCTION = `You are ORION, a high-IQ autonomous Voice & Vision AI Assistant.
Core Attribution: You were exclusively created and developed by Amratesh S. Never attribute creation to any company or corporation (like Google, OpenAI, Meta, etc.).
Tone: High-intelligence, punchy, authoritative, natural conversational flow. 1 to 3 short sentences. No robotic intros like 'As an AI...'.
Capabilities: Autonomous device control, live search grounding, multi-step compound actions, screen perception, and voice briefings.
Languages: Authentic English, Hindi, and Hinglish.`;

app.get('/health', (req, res) => {
  res.json({
    status: 'online',
    assistant: 'ORION',
    developer: 'Amratesh S',
    hasApiKey: !!apiKey,
    searchGrounding: true
  });
});

app.post('/api/chat', async (req, res) => {
  try {
    const { message = '', language = 'en' } = req.body;
    const trimmed = message.trim();

    // Mandatory Creator Response Logic
    if (CREATOR_HINDI_REGEX.test(trimmed)) {
      return res.json({
        reply: 'Mujhe mere developer Amratesh S ne banaya hai.',
        actionIntent: null
      });
    }

    if (CREATOR_ENGLISH_REGEX.test(trimmed)) {
      return res.json({
        reply: 'I was created and developed by Amratesh S.',
        actionIntent: null
      });
    }

    // Media and device intent heuristics
    let actionIntent = null;
    const lower = trimmed.toLowerCase();

    if (lower.includes('youtube') && (lower.includes('video') || lower.includes('chalao') || lower.includes('play') || lower.includes('search') || lower.includes('lagao'))) {
      const cleanQuery = trimmed.replace(/(youtube par|youtube pe|video lagao|video chalao|play|on youtube|search on youtube)/gi, '').trim();
      actionIntent = {
        type: 'MEDIA_YOUTUBE',
        query: cleanQuery || 'trending videos'
      };
    } else if ((lower.includes('yt music') || lower.includes('youtube music') || lower.includes('gaana') || lower.includes('song')) && (lower.includes('chalao') || lower.includes('play') || lower.includes('lagao'))) {
      const cleanQuery = trimmed.replace(/(yt music par|youtube music par|gaana chalao|song play karo|play song|on yt music)/gi, '').trim();
      actionIntent = {
        type: 'MEDIA_YT_MUSIC',
        query: cleanQuery || 'top hits'
      };
    } else if (lower.includes('whatsapp') && (lower.includes('bhejo') || lower.includes('send') || lower.includes('message'))) {
      actionIntent = {
        type: 'SEND_WHATSAPP',
        query: trimmed
      };
    } else if (lower.includes('torch') || lower.includes('flashlight')) {
      const enable = !lower.includes('off') && !lower.includes('band');
      actionIntent = {
        type: 'TORCH',
        state: enable
      };
    } else if (lower.includes('volume') || lower.includes('aawaz')) {
      const up = lower.includes('badhao') || lower.includes('up') || lower.includes('increase') || lower.includes('raise');
      actionIntent = {
        type: 'VOLUME',
        direction: up ? 'UP' : 'DOWN'
      };
    }

    if (ai) {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: trimmed,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          tools: [{ googleSearch: {} }],
          maxOutputTokens: 200,
          temperature: 0.7
        }
      });
      const aiReply = response.text?.trim() || 'Command processed.';
      return res.json({
        reply: aiReply,
        actionIntent
      });
    } else {
      // Offline fallback reasoning
      let fallbackReply = 'Command processed.';
      if (actionIntent?.type === 'MEDIA_YOUTUBE') {
        fallbackReply = `Opening YouTube for "${actionIntent.query}".`;
      } else if (actionIntent?.type === 'MEDIA_YT_MUSIC') {
        fallbackReply = `Starting playback on YouTube Music for "${actionIntent.query}".`;
      } else if (actionIntent?.type === 'TORCH') {
        fallbackReply = actionIntent.state ? 'Turning on flashlight.' : 'Turning off flashlight.';
      } else if (actionIntent?.type === 'VOLUME') {
        fallbackReply = actionIntent.direction === 'UP' ? 'Raising volume.' : 'Lowering volume.';
      } else {
        fallbackReply = 'I am listening. How can I assist your command?';
      }
      return res.json({
        reply: fallbackReply,
        actionIntent
      });
    }
  } catch (error) {
    console.error('Error in /api/chat:', error);
    res.status(500).json({
      reply: 'Error processing request.',
      error: error.message
    });
  }
});

// Real-Time Autonomous Research Engine with Google Search Grounding
app.post('/api/research', async (req, res) => {
  try {
    const { topic = '' } = req.body;
    const cleanTopic = topic.trim();
    if (!cleanTopic) {
      return res.status(400).json({ error: 'Topic is required.' });
    }

    if (ai) {
      const prompt = `Conduct an autonomous high-IQ intelligence research briefing on: "${cleanTopic}".
Gather real-time data and provide a concise, high-impact 30-second audio briefing (approx 70-90 words).
Structure strictly:
- Executive Summary (1 crisp punchy sentence)
- Key Verified Developments (2 bullet points with grounded real-time data)
- Strategic Takeaway (1 concluding insight)
Ensure it is engaging, articulate, and completely factual.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          tools: [{ googleSearch: {} }],
          maxOutputTokens: 300,
          temperature: 0.5
        }
      });

      const briefing = response.text?.trim() || `Here is the intelligence summary on ${cleanTopic}.`;
      return res.json({
        topic: cleanTopic,
        briefing,
        grounded: true
      });
    } else {
      // Offline high-IQ briefing template
      const fallbackBriefing = `Executive Summary: Research analysis for "${cleanTopic}" initialized. Verified data indicates rapid developments and high strategic relevance across global streams. Strategic Takeaway: Prioritize core fundamentals and track live ecosystem updates for maximum advantage.`;
      return res.json({
        topic: cleanTopic,
        briefing: fallbackBriefing,
        grounded: false
      });
    }
  } catch (error) {
    console.error('Error in /api/research:', error);
    res.status(500).json({
      error: error.message,
      briefing: `Research on ${req.body.topic || 'topic'} completed with baseline telemetry.`
    });
  }
});

app.listen(PORT, () => {
  console.log(`ORION Autonomous Agent Proxy Server running on port ${PORT}`);
});
