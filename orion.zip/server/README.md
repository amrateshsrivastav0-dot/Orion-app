# ORION Zero-Leakage Secure AI Proxy

This proxy server ensures **Zero-Leakage API Security**:
- The Android APK contains **NO** hardcoded Gemini API key or credentials.
- The Node.js Express proxy reads `GEMINI_API_KEY` securely from the server environment.
- The Android app connects via secure HTTPS/HTTP REST client to `POST /api/chat`.
- Hardcoded Creator & Developer legal attribution to **Amratesh S** is strictly enforced.

## Setup & Running
```bash
cd server
npm install
export GEMINI_API_KEY="your-gemini-api-key"
npm start
```
