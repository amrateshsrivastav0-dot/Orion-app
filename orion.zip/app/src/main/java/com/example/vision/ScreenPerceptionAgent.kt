package com.example.vision

import android.content.Context
import android.util.Log
import com.example.automation.OrionAccessibilityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * On-Demand Screen Perception (Vision Agent)
 * Analyzes active screen UI nodes, forms, error alerts, and interactive elements
 * on the command "Orion, screen dekho aur batao/karo".
 */
class ScreenPerceptionAgent(private val context: Context) {

    companion object {
        private const val TAG = "ScreenPerceptionAgent"
    }

    data class PerceptionResult(
        val packageName: String,
        val appName: String,
        val summary: String,
        val detectedTexts: List<String>,
        val buttons: List<String>,
        val errorAlert: String?,
        val suggestedAction: String?
    )

    private val _lastPerception = MutableStateFlow<PerceptionResult?>(null)
    val lastPerception: StateFlow<PerceptionResult?> = _lastPerception.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    fun isScreenPerceptionCommand(text: String): Boolean {
        val lower = text.lowercase()
        return lower.contains("screen dekho") ||
                lower.contains("screen par kya hai") ||
                lower.contains("read screen") ||
                lower.contains("what's on my screen") ||
                lower.contains("analyze screen") ||
                lower.contains("screen batao") ||
                lower.contains("screen check karo")
    }

    /**
     * Inspects active window hierarchy and generates cognitive perception summary.
     */
    fun perceiveScreen(): PerceptionResult {
        _isAnalyzing.value = true
        val service = OrionAccessibilityService.instance

        if (service == null) {
            _isAnalyzing.value = false
            val result = PerceptionResult(
                packageName = "unknown",
                appName = "Accessibility Disabled",
                summary = "Accessibility Service is not active. Please enable Orion in Accessibility Settings to allow screen perception.",
                detectedTexts = emptyList(),
                buttons = emptyList(),
                errorAlert = null,
                suggestedAction = "Open Accessibility Settings"
            )
            _lastPerception.value = result
            return result
        }

        val data = service.analyzeScreen()
        _isAnalyzing.value = false

        if (data == null) {
            val result = PerceptionResult(
                packageName = "system",
                appName = "Active Window",
                summary = "Screen is currently obscured or in a secure display mode.",
                detectedTexts = emptyList(),
                buttons = emptyList(),
                errorAlert = null,
                suggestedAction = null
            )
            _lastPerception.value = result
            return result
        }

        val appName = data.packageName.substringAfterLast(".").replaceFirstChar { it.uppercase() }
        val errors = data.errorTexts.firstOrNull()

        val summaryBuilder = StringBuilder()
        summaryBuilder.append("Active screen: $appName. ")

        if (errors != null) {
            summaryBuilder.append("Notice: Error or warning detected: '$errors'. ")
        }

        if (data.inputFields.isNotEmpty()) {
            summaryBuilder.append("Form detected with fields: ${data.inputFields.joinToString(", ")}. ")
        }

        if (data.buttons.isNotEmpty()) {
            summaryBuilder.append("Action buttons: ${data.buttons.take(4).joinToString(", ")}. ")
        } else if (data.visibleTexts.isNotEmpty()) {
            summaryBuilder.append("Visible text: ${data.visibleTexts.take(3).joinToString(". ")}. ")
        }

        val suggested = when {
            errors != null -> "Resolve error: $errors"
            data.buttons.any { it.contains("Submit", true) || it.contains("Done", true) || it.contains("Send", true) } -> "Tap '${data.buttons.firstOrNull { it.contains("Submit", true) || it.contains("Done", true) || it.contains("Send", true) }}'"
            data.buttons.isNotEmpty() -> "Tap '${data.buttons.first()}'"
            else -> null
        }

        val result = PerceptionResult(
            packageName = data.packageName,
            appName = appName,
            summary = summaryBuilder.toString().trim(),
            detectedTexts = data.visibleTexts,
            buttons = data.buttons,
            errorAlert = errors,
            suggestedAction = suggested
        )

        _lastPerception.value = result
        Log.i(TAG, "Screen perception complete: ${result.summary}")
        return result
    }

    /**
     * Executes tap on an element detected on screen matching the text.
     */
    fun performTapOnScreen(elementText: String): Boolean {
        val service = OrionAccessibilityService.instance ?: return false
        return service.clickElementByText(elementText)
    }

    /**
     * Executes tap on the primary action button.
     */
    fun performActionOnFirstButton(): Boolean {
        val service = OrionAccessibilityService.instance ?: return false
        return service.clickFirstActionableButton()
    }
}
