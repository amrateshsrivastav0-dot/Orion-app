package com.example.battery

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Smart Battery & Charging Alerts Engine
 * Monitors battery state via BroadcastReceiver and triggers audible voice announcements
 * upon 100% full charge, <20% low battery threshold, or power connection changes.
 */
class SmartBatteryMonitor(
    private val context: Context,
    private val onAudibleAlert: (String) -> Unit
) {

    companion object {
        private const val TAG = "SmartBatteryMonitor"
    }

    data class BatteryState(
        val level: Int = 100,
        val isCharging: Boolean = false,
        val isFull: Boolean = false,
        val isLow: Boolean = false,
        val temperatureCelsius: Float = 28.0f
    )

    private val _batteryState = MutableStateFlow(BatteryState())
    val batteryState: StateFlow<BatteryState> = _batteryState.asStateFlow()

    private var hasAnnouncedFull = false
    private var hasAnnouncedLow = false

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            when (intent.action) {
                Intent.ACTION_BATTERY_CHANGED -> {
                    val rawLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    val temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0f

                    val level = if (rawLevel >= 0 && scale > 0) {
                        (rawLevel * 100) / scale
                    } else 100

                    val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                            status == BatteryManager.BATTERY_STATUS_FULL
                    val isFull = level >= 100 || status == BatteryManager.BATTERY_STATUS_FULL
                    val isLow = level <= 20 && !isCharging

                    _batteryState.value = BatteryState(
                        level = level,
                        isCharging = isCharging,
                        isFull = isFull,
                        isLow = isLow,
                        temperatureCelsius = temp
                    )

                    // 100% Full Charge Alert Trigger
                    if (isFull && isCharging && !hasAnnouncedFull) {
                        hasAnnouncedFull = true
                        onAudibleAlert("Device is fully charged at 100%. Please unplug to preserve battery health.")
                    } else if (level < 98) {
                        hasAnnouncedFull = false
                    }

                    // Low Battery (< 20%) Alert Trigger
                    if (isLow && !hasAnnouncedLow) {
                        hasAnnouncedLow = true
                        onAudibleAlert("Battery low at $level percent. Please connect charger soon.")
                    } else if (level > 25) {
                        hasAnnouncedLow = false
                    }
                }
                Intent.ACTION_POWER_CONNECTED -> {
                    onAudibleAlert("Power connected. Charging initiated.")
                }
                Intent.ACTION_POWER_DISCONNECTED -> {
                    val current = _batteryState.value.level
                    onAudibleAlert("Power disconnected. Current battery is $current percent.")
                }
            }
        }
    }

    fun startListening() {
        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_BATTERY_CHANGED)
                addAction(Intent.ACTION_POWER_CONNECTED)
                addAction(Intent.ACTION_POWER_DISCONNECTED)
            }
            context.registerReceiver(batteryReceiver, filter)
            Log.d(TAG, "SmartBatteryMonitor registered.")
        } catch (e: Exception) {
            Log.e(TAG, "Error registering battery receiver", e)
        }
    }

    fun stopListening() {
        try {
            context.unregisterReceiver(batteryReceiver)
        } catch (e: Exception) {
            Log.e(TAG, "Error unregistering battery receiver", e)
        }
    }

    fun isBatteryQuery(query: String): Boolean {
        val lower = query.lowercase(Locale.ROOT)
        return lower.contains("battery") ||
                lower.contains("charging") ||
                lower.contains("charge kitna") ||
                lower.contains("kitni percent")
    }

    fun getBatteryReport(): String {
        val state = _batteryState.value
        val chargeStatus = if (state.isCharging) "Currently charging" else "On battery power"
        return "Battery is at ${state.level} percent. $chargeStatus. Temperature is ${state.temperatureCelsius}°C."
    }
}
