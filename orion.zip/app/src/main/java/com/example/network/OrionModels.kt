package com.example.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ChatRequest(
    @Json(name = "message") val message: String,
    @Json(name = "language") val language: String = "en"
)

@JsonClass(generateAdapter = true)
data class ActionIntent(
    @Json(name = "type") val type: String? = null,
    @Json(name = "query") val query: String? = null,
    @Json(name = "state") val state: Boolean? = null,
    @Json(name = "direction") val direction: String? = null
)

@JsonClass(generateAdapter = true)
data class ChatResponse(
    @Json(name = "reply") val reply: String,
    @Json(name = "actionIntent") val actionIntent: ActionIntent? = null
)

@JsonClass(generateAdapter = true)
data class ResearchRequest(
    @Json(name = "topic") val topic: String
)

@JsonClass(generateAdapter = true)
data class ResearchResponse(
    @Json(name = "topic") val topic: String,
    @Json(name = "briefing") val briefing: String,
    @Json(name = "grounded") val grounded: Boolean = true
)
