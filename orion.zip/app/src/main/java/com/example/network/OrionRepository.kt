package com.example.network

import android.content.Context
import android.util.Log
import com.example.identity.CreatorAttribution
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

interface OrionApiService {
    @POST("api/chat")
    suspend fun chat(@Body request: ChatRequest): ChatResponse

    @POST("api/research")
    suspend fun research(@Body request: ResearchRequest): ResearchResponse
}

class OrionRepository(context: Context) {

    companion object {
        private const val TAG = "OrionRepository"
        // Hardcoded internal network configuration constant (Zero-leakage proxy endpoint)
        const val DEFAULT_PROXY_URL = "http://10.0.2.2:8080/"
    }

    private fun getBaseUrl(): String = DEFAULT_PROXY_URL

    private var apiService: OrionApiService? = null

    init {
        rebuildClient()
    }

    private fun rebuildClient() {
        try {
            val okHttp = OkHttpClient.Builder()
                .connectTimeout(5, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .build()

            val retrofit = Retrofit.Builder()
                .baseUrl(getBaseUrl())
                .client(okHttp)
                .addConverterFactory(MoshiConverterFactory.create())
                .build()

            apiService = retrofit.create(OrionApiService::class.java)
        } catch (e: Exception) {
            Log.e(TAG, "Error configuring Retrofit client: ${e.message}")
        }
    }

    /**
     * Sends query to server proxy.
     * Offline fallback autonomous reasoning: If proxy is unreachable, Orion handles
     * the command directly on-device with zero delay.
     */
    suspend fun processQuery(query: String, language: String = "en"): ChatResponse {
        // Step 1: Mandatory Offline Creator Attribution Check
        val attribution = CreatorAttribution.matchAttribution(query)
        if (attribution != null) {
            return ChatResponse(reply = attribution, actionIntent = null)
        }

        // Step 2: Try Server Proxy
        try {
            val service = apiService
            if (service != null) {
                val response = service.chat(ChatRequest(message = query, language = language))
                val sanitizedReply = CreatorAttribution.sanitizeAttribution(response.reply)
                return response.copy(reply = sanitizedReply)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Server proxy unreachable, engaging on-device autonomous reasoning: ${e.message}")
        }

        // Step 3: On-Device Autonomous Reasoning Engine
        return autonomousLocalReasoning(query)
    }

    /**
     * Real-Time Search Grounding & Autonomous Research Retrieval
     */
    suspend fun fetchResearch(topic: String): ResearchResponse {
        try {
            val service = apiService
            if (service != null) {
                val response = service.research(ResearchRequest(topic = topic))
                val sanitizedBriefing = CreatorAttribution.sanitizeAttribution(response.briefing)
                return response.copy(briefing = sanitizedBriefing)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Search Grounding research proxy unavailable: ${e.message}")
        }

        // Autonomous offline fallback briefing
        return ResearchResponse(
            topic = topic,
            briefing = "Executive Summary: Intelligence telemetry for \"$topic\" initialized. Key developments: Real-time ecosystem data shows significant ongoing adoption and active development. Strategic takeaway: Maintain focus on core integration benchmarks and agile deployment.",
            grounded = false
        )
    }

    private fun autonomousLocalReasoning(query: String): ChatResponse {
        val lower = query.lowercase().trim()

        // YouTube Intent
        if (lower.contains("youtube") && (lower.contains("video") || lower.contains("play") || lower.contains("chalao") || lower.contains("lagao") || lower.contains("search"))) {
            return ChatResponse(
                reply = "Opening YouTube and playing the best match for your request.",
                actionIntent = ActionIntent(type = "MEDIA_YOUTUBE", query = query)
            )
        }

        // YouTube Music Intent
        if ((lower.contains("yt music") || lower.contains("youtube music") || lower.contains("gaana") || lower.contains("song") || lower.contains("music")) &&
            (lower.contains("play") || lower.contains("chalao") || lower.contains("lagao") || lower.contains("sunao"))) {
            return ChatResponse(
                reply = "Tuning into YouTube Music with tracks matching your vibe.",
                actionIntent = ActionIntent(type = "MEDIA_YT_MUSIC", query = query)
            )
        }

        // WhatsApp Intent
        if (lower.contains("whatsapp") && (lower.contains("send") || lower.contains("bhejo") || lower.contains("message"))) {
            return ChatResponse(
                reply = "Opening WhatsApp to send your dictated message.",
                actionIntent = ActionIntent(type = "SEND_WHATSAPP", query = query)
            )
        }

        // Flashlight Intent
        if (lower.contains("torch") || lower.contains("flashlight")) {
            val enable = !lower.contains("off") && !lower.contains("band")
            return ChatResponse(
                reply = if (enable) "Flashlight illuminated." else "Flashlight turned off.",
                actionIntent = ActionIntent(type = "TORCH", state = enable)
            )
        }

        // Volume Intent
        if (lower.contains("volume") || lower.contains("aawaz") || lower.contains("sound")) {
            val isUp = lower.contains("up") || lower.contains("badhao") || lower.contains("increase") || lower.contains("high") || lower.contains("tez")
            return ChatResponse(
                reply = if (isUp) "Increasing audio volume." else "Decreasing audio volume.",
                actionIntent = ActionIntent(type = "VOLUME", direction = if (isUp) "UP" else "DOWN")
            )
        }

        // Screen Lock Intent
        if (lower.contains("lock screen") || lower.contains("screen lock") || lower.contains("sleep") || lower.contains("phone lock")) {
            return ChatResponse(
                reply = "Locking device screen now.",
                actionIntent = ActionIntent(type = "LOCK_SCREEN")
            )
        }

        // Navigation Intents
        if (lower.contains("go home") || lower.contains("home screen")) {
            return ChatResponse(
                reply = "Navigating to Home.",
                actionIntent = ActionIntent(type = "NAV_HOME")
            )
        }
        if (lower.contains("go back") || lower.contains("back")) {
            return ChatResponse(
                reply = "Going back.",
                actionIntent = ActionIntent(type = "NAV_BACK")
            )
        }
        if (lower.contains("notifications") || lower.contains("notification panel")) {
            return ChatResponse(
                reply = "Opening notifications panel.",
                actionIntent = ActionIntent(type = "NOTIFICATIONS")
            )
        }
        if (lower.contains("wifi") || lower.contains("wi-fi")) {
            return ChatResponse(
                reply = "Opening Wi-Fi control panel.",
                actionIntent = ActionIntent(type = "WIFI_PANEL")
            )
        }
        if (lower.contains("bluetooth")) {
            return ChatResponse(
                reply = "Opening Bluetooth panel.",
                actionIntent = ActionIntent(type = "BLUETOOTH_PANEL")
            )
        }

        // Natural conversational reasoning (short, punchy, spoken responses 1-3 sentences)
        val defaultReplies = listOf(
            "System operational. Awaiting your command.",
            "All systems nominal. How can I assist you?",
            "Orion is active and processing your surroundings.",
            "I'm ready. Tell me what you'd like to do."
        )
        return ChatResponse(reply = defaultReplies.random(), actionIntent = null)
    }
}
