package com.example.telecom

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import android.telephony.TelephonyManager
import android.util.Log
import com.example.MainActivity

/**
 * High-Priority Background Wakeup BroadcastReceiver for Phone State Events.
 * Immediately acquires WakeLock to wake Orion up from standby/sleep
 * and bring the assistant to foreground over lock screen for call screening.
 */
class CallScreeningReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "CallScreeningReceiver"
        private const val WAKE_LOCK_TAG = "Orion:CallWakeLock"
        private const val WAKE_LOCK_TIMEOUT_MS = 30_000L // 30 seconds
    }

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == TelephonyManager.ACTION_PHONE_STATE_CHANGED) {
            val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
            val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
            Log.i(TAG, "PHONE_STATE broadcast received with high priority: state=$state, number=$number")

            // 1. Acquire High-Priority WakeLock to wake CPU from standby/sleep
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            val wakeLock = powerManager?.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                WAKE_LOCK_TAG
            )
            wakeLock?.acquire(WAKE_LOCK_TIMEOUT_MS)

            // 2. If ringing, immediately bring Orion forward to screen call even over lock screen
            if (state == TelephonyManager.EXTRA_STATE_RINGING) {
                try {
                    val wakeIntent = Intent(context, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                                Intent.FLAG_ACTIVITY_CLEAR_TOP
                        putExtra("EXTRA_INCOMING_CALL", true)
                        putExtra("EXTRA_INCOMING_NUMBER", number ?: "Unknown Caller")
                    }
                    context.startActivity(wakeIntent)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to launch activity from background receiver: ${e.message}", e)
                }
            }

            // 3. Trigger SmartCallManager auto-answer and AI screening pipeline
            SmartCallManager.init(context).onCallStateChanged(state, number)
        }
    }
}
