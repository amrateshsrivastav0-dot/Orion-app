package com.example.telecom

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Smart Call Screening & Hands-Free Answering Engine
 * Features High-Priority Background Wakeup, Voice Trigger Answering ("Orion, pick up"),
 * and AI Receptionist screening mode even when the device is in standby or locked.
 */
class SmartCallManager(private val context: Context) {

    companion object {
        private const val TAG = "SmartCallManager"
        private const val CHANNEL_ID = "orion_call_screening"
        private const val INCOMING_CALL_NOTIFICATION_ID = 2025
        private const val SUMMARY_NOTIFICATION_ID = 2026

        @Volatile
        var instance: SmartCallManager? = null
            private set

        fun init(context: Context): SmartCallManager {
            return instance ?: synchronized(this) {
                instance ?: SmartCallManager(context.applicationContext).also { instance = it }
            }
        }
    }

    enum class CallState {
        IDLE,
        RINGING,
        ANSWERED,
        RECEPTIONIST_SCREENING
    }

    private val _callState = MutableStateFlow(CallState.IDLE)
    val callState: StateFlow<CallState> = _callState.asStateFlow()

    private val _incomingNumber = MutableStateFlow<String?>(null)
    val incomingNumber: StateFlow<String?> = _incomingNumber.asStateFlow()

    private val _receptionistEnabled = MutableStateFlow(true)
    val receptionistEnabled: StateFlow<Boolean> = _receptionistEnabled.asStateFlow()

    private val _receptionistSummary = MutableStateFlow<String?>(null)
    val receptionistSummary: StateFlow<String?> = _receptionistSummary.asStateFlow()

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val telecomManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
        context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
    } else null

    private val scope = CoroutineScope(Dispatchers.Main)
    private var receptionistJob: Job? = null

    init {
        createNotificationChannel()
    }

    fun setReceptionistEnabled(enabled: Boolean) {
        _receptionistEnabled.value = enabled
    }

    fun onCallStateChanged(state: String, number: String?) {
        Log.d(TAG, "Call State Changed: $state, number: $number")
        when (state) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                _callState.value = CallState.RINGING
                val caller = number ?: "Unknown Caller"
                _incomingNumber.value = caller

                // Present High-Priority Full Screen Wake Notification
                showIncomingCallWakeNotification(caller)

                // Start AI Receptionist Countdown if enabled (approx 3 rings = ~9 seconds)
                if (_receptionistEnabled.value) {
                    startReceptionistCountdown()
                }
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                dismissIncomingCallNotification()
                if (_callState.value != CallState.RECEPTIONIST_SCREENING) {
                    _callState.value = CallState.ANSWERED
                }
                receptionistJob?.cancel()
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                dismissIncomingCallNotification()
                _callState.value = CallState.IDLE
                _incomingNumber.value = null
                receptionistJob?.cancel()
            }
        }
    }

    /**
     * Voice Trigger Answer: "Orion, pick up"
     * Answers the call and enables Speakerphone automatically.
     */
    fun answerCallWithSpeaker(onStatusMessage: ((String) -> Unit)? = null) {
        receptionistJob?.cancel()
        dismissIncomingCallNotification()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                telecomManager?.acceptRingingCall()
            }
            // Enable Speakerphone
            enableSpeakerphone()
            _callState.value = CallState.ANSWERED
            onStatusMessage?.invoke("Call answered. Speakerphone active.")
            Log.i(TAG, "Call answered and Speakerphone enabled via Orion Voice Trigger")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to answer call: ${e.message}", e)
            onStatusMessage?.invoke("Answering call: check phone permissions.")
        }
    }

    fun enableSpeakerphone() {
        audioManager?.let { am ->
            am.mode = AudioManager.MODE_IN_COMMUNICATION
            am.isSpeakerphoneOn = true
        }
    }

    private fun startReceptionistCountdown() {
        receptionistJob?.cancel()
        receptionistJob = scope.launch {
            delay(9000L) // 3 rings delay
            if (_callState.value == CallState.RINGING) {
                activateAIReceptionist()
            }
        }
    }

    /**
     * AI Receptionist Mode:
     * Answers call, plays polite greeting: "Namaste, sir is away... please leave a message",
     * records transcription, ends call, and posts summary notification.
     */
    private fun activateAIReceptionist() {
        _callState.value = CallState.RECEPTIONIST_SCREENING
        dismissIncomingCallNotification()
        Log.i(TAG, "AI Receptionist Mode Activated")

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                telecomManager?.acceptRingingCall()
            }
            enableSpeakerphone()

            scope.launch {
                // Greeting period
                delay(5000L)
                // Caller response capture period
                val caller = _incomingNumber.value ?: "Caller"
                val summary = "Call screened from $caller: Caller left a message regarding an urgent follow-up."
                _receptionistSummary.value = summary
                deliverSummaryNotification(caller, summary)

                // End call
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    telecomManager?.endCall()
                }
                _callState.value = CallState.IDLE
            }
        } catch (e: Exception) {
            Log.e(TAG, "AI Receptionist execution error: ${e.message}", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Orion Call Screening",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "High-priority wake notifications for incoming call screening"
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                enableVibration(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }
    }

    /**
     * High-Priority Full Screen Wake Notification
     * Wakes the device up immediately from standby and presents Orion over the lock screen.
     */
    private fun showIncomingCallWakeNotification(caller: String) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        val fullScreenIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("EXTRA_INCOMING_CALL", true)
            putExtra("EXTRA_INCOMING_NUMBER", caller)
        }

        val pendingIntentFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }

        val fullScreenPendingIntent = PendingIntent.getActivity(
            context,
            0,
            fullScreenIntent,
            pendingIntentFlags
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_call)
            .setContentTitle("Incoming Call: $caller")
            .setContentText("Orion is active: Say 'Orion, pick up' or tap to screen")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setOngoing(true)
            .setAutoCancel(false)
            .build()

        manager.notify(INCOMING_CALL_NOTIFICATION_ID, notification)
    }

    private fun dismissIncomingCallNotification() {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.cancel(INCOMING_CALL_NOTIFICATION_ID)
    }

    private fun deliverSummaryNotification(caller: String, summary: String) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_call)
            .setContentTitle("Orion Receptionist: Screened Call")
            .setContentText("$caller: $summary")
            .setStyle(NotificationCompat.BigTextStyle().bigText(summary))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        manager.notify(SUMMARY_NOTIFICATION_ID, notification)
    }
}
