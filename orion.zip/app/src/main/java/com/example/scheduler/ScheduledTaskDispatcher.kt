package com.example.scheduler

import android.content.Context
import android.util.Log
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Scheduled Task Dispatcher
 * Dispatches exact time-based WorkManager background tasks, reminders, and alerts.
 */
class ScheduledTaskDispatcher(private val context: Context) {

    companion object {
        private const val TAG = "ScheduledTaskDispatcher"
    }

    private val workManager = WorkManager.getInstance(context)

    /**
     * Schedules a reminder after a specific delay in minutes.
     */
    fun scheduleReminder(delayMinutes: Long, message: String): String {
        return try {
            val inputData = Data.Builder()
                .putString(OrionTaskWorker.KEY_TITLE, "Orion Scheduled Reminder")
                .putString(OrionTaskWorker.KEY_MESSAGE, message)
                .putString(OrionTaskWorker.KEY_ACTION_TYPE, "REMINDER")
                .build()

            val workRequest = OneTimeWorkRequestBuilder<OrionTaskWorker>()
                .setInitialDelay(delayMinutes.coerceAtLeast(1L), TimeUnit.MINUTES)
                .setInputData(inputData)
                .addTag("orion_scheduled_reminder")
                .build()

            workManager.enqueue(workRequest)
            "Reminder successfully scheduled for $delayMinutes minute${if (delayMinutes > 1) "s" else ""} from now: \"$message\""
        } catch (e: Exception) {
            Log.e(TAG, "Failed to schedule reminder", e)
            "Failed to schedule reminder. WorkManager error."
        }
    }

    /**
     * Checks if a command is a scheduling / reminder command.
     */
    fun isScheduleCommand(query: String): Boolean {
        val lower = query.lowercase(Locale.ROOT)
        return lower.contains("remind me in") ||
                lower.contains("remind me after") ||
                lower.contains("schedule reminder") ||
                lower.contains("minute baad yaad dilana") ||
                lower.contains("minute baad bata dena") ||
                lower.contains("set reminder for")
    }

    /**
     * Parses delay in minutes and reminder message from voice query.
     */
    fun parseScheduleCommand(query: String): Pair<Long, String> {
        val lower = query.lowercase(Locale.ROOT)
        val regex = Regex("""(\d+)\s*(min|minute|minutes)""")
        val match = regex.find(lower)
        val minutes = match?.groupValues?.get(1)?.toLongOrNull() ?: 5L

        // Clean out prefix to extract content
        var reminderText = query
        val cleanPatterns = listOf(
            Regex("""remind me in \d+\s*(min|minute|minutes) (to|that)?""", RegexOption.IGNORE_CASE),
            Regex("""remind me after \d+\s*(min|minute|minutes) (to|that)?""", RegexOption.IGNORE_CASE),
            Regex("""\d+\s*(min|minute|minutes) baad""", RegexOption.IGNORE_CASE)
        )
        for (pattern in cleanPatterns) {
            reminderText = pattern.replace(reminderText, "").trim()
        }

        if (reminderText.isBlank()) {
            reminderText = "Scheduled check-in"
        }

        return Pair(minutes, reminderText)
    }
}
