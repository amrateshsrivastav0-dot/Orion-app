package com.example.notifications

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Intelligent Notification Screener & Smart Auto-Reply Engine
 * Filters promotional spam, flags urgent notifications (OTP/WhatsApp/Emergency),
 * provides voice summaries, and enables autonomous context-aware auto-replies.
 */
class OrionNotificationListenerService : NotificationListenerService() {

    companion object {
        private const val TAG = "OrionNotifService"

        @Volatile
        var instance: OrionNotificationListenerService? = null
            private set

        private val _screenedNotifications = MutableStateFlow<List<ScreenedNotification>>(emptyList())
        val screenedNotifications: StateFlow<List<ScreenedNotification>> = _screenedNotifications.asStateFlow()

        private val _latestUrgentNotification = MutableStateFlow<ScreenedNotification?>(null)
        val latestUrgentNotification: StateFlow<ScreenedNotification?> = _latestUrgentNotification.asStateFlow()

        fun isNotificationAccessGranted(context: Context): Boolean {
            val component = ComponentName(context, OrionNotificationListenerService::class.java)
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
            return flat?.contains(component.flattenToString()) == true
        }

        fun openNotificationAccessSettings(context: Context) {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            } else {
                Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
            }
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
        }
    }

    data class ScreenedNotification(
        val key: String,
        val packageName: String,
        val appName: String,
        val title: String,
        val text: String,
        val timestamp: Long,
        val isSpam: Boolean,
        val isUrgent: Boolean,
        val hasReplyAction: Boolean,
        @Transient val replyAction: Notification.Action? = null,
        @Transient val remoteInput: RemoteInput? = null
    )

    private val spamKeywords = listOf(
        "discount", "coupon", "promo code", "50% off", "flat 70%",
        "cashback", "sale", "win cash", "jackpot", "exclusive offer",
        "recharge now", "hurry up", "limited period", "sponsored",
        "unmissable deal", "claim your prize", "free spins"
    )

    private val urgentKeywords = listOf(
        "otp", "verification code", "emergency", "urgent", "security alert",
        "debited", "credited", "bank", "calling", "missed call", "important",
        "asap", "jaldi", "accident", "hospital"
    )

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        Log.i(TAG, "Orion Notification Listener Connected")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (instance == this) {
            instance = null
        }
        Log.w(TAG, "Orion Notification Listener Disconnected")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val extras = sbn.notification.extras ?: return

        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim() ?: ""

        if (title.isEmpty() && text.isEmpty()) return

        val pkg = sbn.packageName ?: "unknown"
        val combined = "$title $text".lowercase()

        // 1. Spam Filtering
        val isSpam = spamKeywords.any { combined.contains(it) }

        // 2. Urgency Detection
        val isMessagingApp = pkg.contains("whatsapp", true) ||
                pkg.contains("messaging", true) ||
                pkg.contains("telegram", true) ||
                pkg.contains("signal", true)
        val hasUrgentKeyword = urgentKeywords.any { combined.contains(it) }
        val isUrgent = (!isSpam && (isMessagingApp || hasUrgentKeyword))

        // 3. Extract Direct Reply Action & RemoteInput
        var replyAction: Notification.Action? = null
        var foundRemoteInput: RemoteInput? = null

        sbn.notification.actions?.forEach { action ->
            action.remoteInputs?.firstOrNull()?.let { input ->
                replyAction = action
                foundRemoteInput = input
            }
        }

        val appName = pkg.substringAfterLast(".").replaceFirstChar { it.uppercase() }

        val screened = ScreenedNotification(
            key = sbn.key,
            packageName = pkg,
            appName = appName,
            title = title,
            text = text,
            timestamp = sbn.postTime,
            isSpam = isSpam,
            isUrgent = isUrgent,
            hasReplyAction = foundRemoteInput != null,
            replyAction = replyAction,
            remoteInput = foundRemoteInput
        )

        val currentList = _screenedNotifications.value.toMutableList()
        currentList.removeAll { it.key == screened.key }
        currentList.add(0, screened)
        _screenedNotifications.value = currentList.take(50)

        if (isUrgent && !isSpam) {
            _latestUrgentNotification.value = screened
            Log.i(TAG, "Urgent Notification Detected from $appName: $title")
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val currentList = _screenedNotifications.value.toMutableList()
        currentList.removeAll { it.key == sbn.key }
        _screenedNotifications.value = currentList
    }

    /**
     * Autonomous Smart Auto-Reply to a Screened Notification (WhatsApp / SMS).
     */
    fun sendAutoReply(notificationKey: String, replyText: String): Boolean {
        val target = _screenedNotifications.value.find { it.key == notificationKey } ?: return false
        val action = target.replyAction ?: return false
        val remoteInput = target.remoteInput ?: return false

        return try {
            val intent = Intent()
            val bundle = Bundle()
            bundle.putCharSequence(remoteInput.resultKey, replyText)
            RemoteInput.addResultsToIntent(arrayOf(remoteInput), intent, bundle)
            action.actionIntent.send(this, 0, intent)
            Log.i(TAG, "Autonomous reply sent to ${target.appName}: $replyText")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send auto reply: ${e.message}", e)
            false
        }
    }
}
