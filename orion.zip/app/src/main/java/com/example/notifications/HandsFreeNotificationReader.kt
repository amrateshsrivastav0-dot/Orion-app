package com.example.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Hands-Free Headset Notification Reader
 * Detects wired and Bluetooth headsets and audibly reads sender names & summaries
 * for high-priority incoming messages without requiring screen glance.
 */
class HandsFreeNotificationReader(
    private val context: Context,
    private val onAnnounce: (String) -> Unit
) {

    companion object {
        private const val TAG = "HandsFreeReader"
    }

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val _isHeadsetConnected = MutableStateFlow(false)
    val isHeadsetConnected: StateFlow<Boolean> = _isHeadsetConnected.asStateFlow()

    private val _isEnabled = MutableStateFlow(true)
    val isEnabled: StateFlow<Boolean> = _isEnabled.asStateFlow()

    private val headsetPlugReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_HEADSET_PLUG) {
                val state = intent.getIntExtra("state", -1)
                _isHeadsetConnected.value = state == 1 || checkAudioOutputDevices()
                Log.d(TAG, "Headset plug changed: state=$state, connected=${_isHeadsetConnected.value}")
            }
        }
    }

    private var audioDeviceCallback: AudioDeviceCallback? = null

    init {
        checkCurrentConnection()
        setupAudioDeviceCallback()
    }

    fun start() {
        try {
            val filter = IntentFilter(Intent.ACTION_HEADSET_PLUG)
            context.registerReceiver(headsetPlugReceiver, filter)
            checkCurrentConnection()
        } catch (e: Exception) {
            Log.e(TAG, "Error registering headset receiver", e)
        }
    }

    fun stop() {
        try {
            context.unregisterReceiver(headsetPlugReceiver)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && audioDeviceCallback != null) {
                audioManager?.unregisterAudioDeviceCallback(audioDeviceCallback!!)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping HandsFreeNotificationReader", e)
        }
    }

    fun toggleEnabled(enabled: Boolean) {
        _isEnabled.value = enabled
    }

    private fun setupAudioDeviceCallback() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            audioDeviceCallback = object : AudioDeviceCallback() {
                override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
                    checkCurrentConnection()
                }

                override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
                    checkCurrentConnection()
                }
            }
            audioManager?.registerAudioDeviceCallback(audioDeviceCallback!!, null)
        }
    }

    fun checkCurrentConnection() {
        _isHeadsetConnected.value = checkAudioOutputDevices()
    }

    private fun checkAudioOutputDevices(): Boolean {
        if (audioManager == null) return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            for (device in devices) {
                when (device.type) {
                    AudioDeviceInfo.TYPE_WIRED_HEADSET,
                    AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                    AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                    AudioDeviceInfo.TYPE_BLE_HEADSET,
                    AudioDeviceInfo.TYPE_USB_HEADSET -> return true
                }
            }
        } else {
            @Suppress("DEPRECATION")
            return audioManager.isWiredHeadsetOn || audioManager.isBluetoothA2dpOn || audioManager.isBluetoothScoOn
        }
        return false
    }

    fun simulateHeadsetStateForTesting(connected: Boolean) {
        _isHeadsetConnected.value = connected
    }

    /**
     * Inspects a screened notification and announces it if headset is active.
     */
    fun onScreenedNotificationReceived(notification: OrionNotificationListenerService.ScreenedNotification) {
        if (!_isEnabled.value || !_isHeadsetConnected.value) return

        // Priority packages (messaging, calls, OTPs)
        val isMessagingApp = notification.packageName.contains("whatsapp") ||
                notification.packageName.contains("telegram") ||
                notification.packageName.contains("mms") ||
                notification.packageName.contains("messaging")

        if (notification.isUrgent || isMessagingApp) {
            val isOtp = notification.title.contains("OTP", ignoreCase = true) ||
                    notification.text.contains("OTP", ignoreCase = true) ||
                    notification.text.contains("verification code", ignoreCase = true)
            val spokenText = if (isOtp) {
                "Incoming OTP from ${notification.appName}: ${notification.text}"
            } else {
                "Message from ${notification.title} on ${notification.appName}: ${notification.text}"
            }
            onAnnounce(spokenText)
        }
    }
}
