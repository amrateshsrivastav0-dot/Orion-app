package com.example.automation

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * Multi-Step Chained Action Execution Engine
 * Autonomously decomposes complex, compound spoken commands into discrete action steps
 * and executes them sequentially in the background without user intervention.
 */
class ChainedActionPlanner(
    private val context: Context,
    private val deviceController: DeviceController,
    private val mediaBrain: MediaBrain
) {

    companion object {
        private const val TAG = "ChainedActionPlanner"
    }

    data class ActionStep(
        val type: StepType,
        val description: String,
        val query: String? = null,
        val state: Boolean? = null,
        val delayAfterMs: Long = 1000L
    )

    enum class StepType {
        SET_ALARM,
        MEDIA_YOUTUBE,
        MEDIA_YT_MUSIC,
        SEND_WHATSAPP,
        TORCH,
        VOLUME,
        LOCK_SCREEN,
        NAV_HOME,
        NAV_BACK,
        NOTIFICATIONS,
        WIFI_PANEL,
        BLUETOOTH_PANEL,
        CUSTOM_ANNOUNCE
    }

    data class ExecutionState(
        val isExecuting: Boolean = false,
        val currentStepIndex: Int = 0,
        val totalSteps: Int = 0,
        val statusMessage: String = ""
    )

    private val _executionState = MutableStateFlow(ExecutionState())
    val executionState: StateFlow<ExecutionState> = _executionState.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Main)
    private var activeJob: kotlinx.coroutines.Job? = null

    fun cancelChain() {
        activeJob?.cancel()
        _executionState.value = ExecutionState(
            isExecuting = false,
            statusMessage = "Execution cancelled by user."
        )
    }

    /**
     * Detects if an input sentence is a compound / chained command.
     */
    fun isCompoundCommand(text: String): Boolean {
        val lower = text.lowercase()
        val splitWords = listOf(" and ", " aur ", " phir ", " then ", " also ", ", ")
        return splitWords.any { lower.contains(it) } && parseCompoundCommand(text).size > 1
    }

    /**
     * Parses compound speech input into an ordered list of ActionSteps.
     */
    fun parseCompoundCommand(text: String): List<ActionStep> {
        val clauses = text.split(Regex("(?i)(\\s+and\\s+|\\s+aur\\s+|\\s+phir\\s+|\\s+then\\s+|\\s+also\\s+|,\\s*)"))
            .map { it.trim() }
            .filter { it.length > 2 }

        val steps = mutableListOf<ActionStep>()

        for (clause in clauses) {
            val lower = clause.lowercase()

            // 1. Alarm
            if (lower.contains("alarm") || lower.contains("wake me")) {
                val timeMatch = Regex("(\\d{1,2})(:(\\d{2}))?\\s*(am|pm)?", RegexOption.IGNORE_CASE).find(lower)
                val hour = timeMatch?.groupValues?.get(1)?.toIntOrNull() ?: 7
                val minute = timeMatch?.groupValues?.get(3)?.toIntOrNull() ?: 0
                val isPm = timeMatch?.groupValues?.get(4)?.lowercase() == "pm"
                val adjustedHour = if (isPm && hour < 12) hour + 12 else hour

                steps.add(
                    ActionStep(
                        type = StepType.SET_ALARM,
                        description = "Set alarm for %02d:%02d".format(adjustedHour, minute),
                        query = "$adjustedHour:$minute",
                        delayAfterMs = 1200L
                    )
                )
            }
            // 2. YouTube
            else if (lower.contains("youtube") || (lower.contains("video") && (lower.contains("play") || lower.contains("chalao") || lower.contains("find") || lower.contains("search")))) {
                val clean = clause.replace(Regex("(?i)(youtube par|youtube pe|video lagao|video chalao|find a|search for|on youtube|play)"), "").trim()
                steps.add(
                    ActionStep(
                        type = StepType.MEDIA_YOUTUBE,
                        description = "Play on YouTube: ${clean.ifEmpty { "trending" }}",
                        query = clean.ifEmpty { "trending" },
                        delayAfterMs = 1500L
                    )
                )
            }
            // 3. YouTube Music
            else if (lower.contains("yt music") || lower.contains("youtube music") || ((lower.contains("song") || lower.contains("gaana")) && (lower.contains("play") || lower.contains("chalao")))) {
                val clean = clause.replace(Regex("(?i)(yt music par|youtube music par|song play karo|play song|gaana chalao|on yt music)"), "").trim()
                steps.add(
                    ActionStep(
                        type = StepType.MEDIA_YT_MUSIC,
                        description = "Play music: ${clean.ifEmpty { "top hits" }}",
                        query = clean.ifEmpty { "top hits" },
                        delayAfterMs = 1500L
                    )
                )
            }
            // 4. WhatsApp
            else if (lower.contains("whatsapp") || (lower.contains("message") && (lower.contains("send") || lower.contains("bhejo")))) {
                steps.add(
                    ActionStep(
                        type = StepType.SEND_WHATSAPP,
                        description = "Prepare WhatsApp message: $clause",
                        query = clause,
                        delayAfterMs = 1500L
                    )
                )
            }
            // 5. Torch / Flashlight
            else if (lower.contains("torch") || lower.contains("flashlight")) {
                val enable = !lower.contains("off") && !lower.contains("band")
                steps.add(
                    ActionStep(
                        type = StepType.TORCH,
                        description = if (enable) "Turn on flashlight" else "Turn off flashlight",
                        state = enable,
                        delayAfterMs = 800L
                    )
                )
            }
            // 6. Volume
            else if (lower.contains("volume") || lower.contains("aawaz")) {
                val up = lower.contains("up") || lower.contains("badhao") || lower.contains("increase") || lower.contains("raise")
                steps.add(
                    ActionStep(
                        type = StepType.VOLUME,
                        description = if (up) "Raise volume" else "Lower volume",
                        state = up,
                        delayAfterMs = 600L
                    )
                )
            }
            // 7. Navigation
            else if (lower.contains("home") || lower.contains("home screen")) {
                steps.add(
                    ActionStep(
                        type = StepType.NAV_HOME,
                        description = "Go Home",
                        delayAfterMs = 800L
                    )
                )
            }
            else if (lower.contains("notifications")) {
                steps.add(
                    ActionStep(
                        type = StepType.NOTIFICATIONS,
                        description = "Open notifications panel",
                        delayAfterMs = 800L
                    )
                )
            }
            else if (lower.contains("lock screen") || lower.contains("phone lock")) {
                steps.add(
                    ActionStep(
                        type = StepType.LOCK_SCREEN,
                        description = "Lock screen",
                        delayAfterMs = 800L
                    )
                )
            }
        }

        return steps
    }

    /**
     * Executes the parsed action steps sequentially.
     */
    fun executeChain(steps: List<ActionStep>, onProgress: (String) -> Unit, onComplete: (String) -> Unit) {
        if (steps.isEmpty()) return

        activeJob = scope.launch {
            _executionState.value = ExecutionState(
                isExecuting = true,
                currentStepIndex = 0,
                totalSteps = steps.size,
                statusMessage = "Starting ${steps.size}-step execution chain..."
            )

            val summaryList = steps.mapIndexed { idx, s -> "${idx + 1}. ${s.description}" }.joinToString(", ")
            onProgress("Executing ${steps.size} chained actions: $summaryList")

            for ((index, step) in steps.withIndex()) {
                _executionState.value = ExecutionState(
                    isExecuting = true,
                    currentStepIndex = index + 1,
                    totalSteps = steps.size,
                    statusMessage = "Step ${index + 1}/${steps.size}: ${step.description}"
                )
                Log.i(TAG, "Executing Step ${index + 1}/${steps.size}: ${step.description}")

                executeSingleStep(step)
                delay(step.delayAfterMs)
            }

            _executionState.value = ExecutionState(
                isExecuting = false,
                currentStepIndex = steps.size,
                totalSteps = steps.size,
                statusMessage = "All ${steps.size} actions completed successfully."
            )
            onComplete("All ${steps.size} actions executed smoothly without interruption.")
        }
    }

    private fun executeSingleStep(step: ActionStep) {
        when (step.type) {
            StepType.SET_ALARM -> {
                val parts = step.query?.split(":")
                val hour = parts?.getOrNull(0)?.toIntOrNull() ?: 7
                val minute = parts?.getOrNull(1)?.toIntOrNull() ?: 0
                deviceController.setAlarm(hour, minute, "Orion Chained Alarm")
            }
            StepType.MEDIA_YOUTUBE -> {
                mediaBrain.launchYouTube(step.query ?: "trending")
            }
            StepType.MEDIA_YT_MUSIC -> {
                mediaBrain.launchYouTubeMusic(step.query ?: "top hits")
            }
            StepType.SEND_WHATSAPP -> {
                mediaBrain.launchWhatsApp(step.query ?: "")
            }
            StepType.TORCH -> {
                if (step.state != null) {
                    deviceController.setTorch(step.state)
                } else {
                    deviceController.toggleTorch()
                }
            }
            StepType.VOLUME -> {
                if (step.state == true) {
                    deviceController.raiseVolume()
                } else {
                    deviceController.lowerVolume()
                }
            }
            StepType.LOCK_SCREEN -> deviceController.lockScreen()
            StepType.NAV_HOME -> deviceController.goHome()
            StepType.NAV_BACK -> deviceController.goBack()
            StepType.NOTIFICATIONS -> deviceController.openNotifications()
            StepType.WIFI_PANEL -> deviceController.openWifiPanel()
            StepType.BLUETOOTH_PANEL -> deviceController.openBluetoothPanel()
            StepType.CUSTOM_ANNOUNCE -> {}
        }
    }
}
