package com.example.automation

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.util.Log

/**
 * Autonomous Reasoning & Media Brain
 * Handles YouTube, YT Music, and messaging deep automation with native Android intents.
 */
class MediaBrain(private val context: Context) {

    companion object {
        private const val TAG = "MediaBrain"
        const val PKG_YOUTUBE = "com.google.android.youtube"
        const val PKG_YT_MUSIC = "com.google.android.apps.youtube.music"
        const val PKG_WHATSAPP = "com.whatsapp"
    }

    /**
     * Plays or searches a video on YouTube.
     * Extracts autonomous contextual query and launches playback instantly.
     */
    fun launchYouTube(query: String): Boolean {
        val cleanQuery = extractYouTubeQuery(query)
        Log.d(TAG, "Launching YouTube for query: $cleanQuery")

        return try {
            // First attempt: YouTube search intent targeting YouTube package
            val intent = Intent(Intent.ACTION_SEARCH).apply {
                setPackage(PKG_YOUTUBE)
                putExtra("query", cleanQuery)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                true
            } else {
                // Fallback: Direct YouTube web/app URL view intent
                val encodedQuery = Uri.encode(cleanQuery)
                val urlIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encodedQuery")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(urlIntent)
                true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch YouTube: ${e.message}", e)
            false
        }
    }

    /**
     * Plays or searches music on YouTube Music.
     * Uses MEDIA_PLAY_FROM_SEARCH or ACTION_VIEW targeting YT Music.
     */
    fun launchYouTubeMusic(query: String): Boolean {
        val cleanQuery = extractMusicQuery(query)
        Log.d(TAG, "Launching YouTube Music for: $cleanQuery")

        return try {
            // Attempt 1: Media Play from search intent targeting YT Music
            val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                setPackage(PKG_YT_MUSIC)
                putExtra(MediaStore.EXTRA_MEDIA_FOCUS, MediaStore.Audio.Artists.ENTRY_CONTENT_TYPE)
                putExtra(SearchManager.QUERY, cleanQuery)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                true
            } else {
                // Attempt 2: Direct YT Music search view
                val encodedQuery = Uri.encode(cleanQuery)
                val searchIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/search?q=$encodedQuery")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(searchIntent)
                true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch YouTube Music: ${e.message}", e)
            false
        }
    }

    /**
     * Launches WhatsApp to send a dictated message to a contact or general chat.
     */
    fun launchWhatsApp(dictation: String, phoneNumber: String? = null): Boolean {
        return try {
            OrionAccessibilityService.instance?.prepareWhatsAppSend(dictation)

            val uri = if (!phoneNumber.isNullOrEmpty()) {
                val cleanPhone = phoneNumber.replace(Regex("[^0-9+]"), "")
                val encodedMsg = Uri.encode(dictation)
                Uri.parse("https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedMsg")
            } else {
                val encodedMsg = Uri.encode(dictation)
                Uri.parse("whatsapp://send?text=$encodedMsg")
            }

            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage(PKG_WHATSAPP)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }

            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
                true
            } else {
                // Fallback: general share intent
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, dictation)
                    setPackage(PKG_WHATSAPP)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(sendIntent)
                true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch WhatsApp: ${e.message}", e)
            false
        }
    }

    private fun extractYouTubeQuery(input: String): String {
        var query = input
            .replace(Regex("(?i)(youtube par|youtube pe|video lagao|video chalao|best video|search karo|dekho|dikhao|play on youtube)"), "")
            .trim()
        if (query.isEmpty()) query = "trending"
        return query
    }

    private fun extractMusicQuery(input: String): String {
        var query = input
            .replace(Regex("(?i)(yt music par|youtube music par|gaana chalao|song play karo|mood ke hisab se|gaana lagao|music chalao|play music)"), "")
            .trim()
        if (query.isEmpty()) query = "top hits"
        return query
    }
}
