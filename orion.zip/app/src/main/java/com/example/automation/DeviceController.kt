package com.example.automation

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.util.Log

/**
 * Deep Hardware & Settings Control Module
 * Controls Volume, Torch, and System Settings Panels (Wi-Fi, Bluetooth).
 * NOTE: As per system requirement, mobile data toggles are strictly excluded.
 */
class DeviceController(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    private var isTorchOn = false

    companion object {
        private const val TAG = "DeviceController"
    }

    // --- Volume Management ---

    fun raiseVolume(): Int {
        val am = audioManager ?: return -1
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
        return am.getStreamVolume(AudioManager.STREAM_MUSIC)
    }

    fun lowerVolume(): Int {
        val am = audioManager ?: return -1
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        return am.getStreamVolume(AudioManager.STREAM_MUSIC)
    }

    fun muteVolume(): Boolean {
        val am = audioManager ?: return false
        am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
        return true
    }

    fun maximizeVolume(): Int {
        val am = audioManager ?: return -1
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI)
        return max
    }

    fun getVolumePercentage(): Int {
        val am = audioManager ?: return 0
        val curr = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return (curr * 100) / max
    }

    // --- Torch / Flashlight ---

    fun toggleTorch(): Boolean {
        return setTorch(!isTorchOn)
    }

    fun setTorch(enable: Boolean): Boolean {
        val cm = cameraManager ?: return false
        return try {
            val cameraIds = cm.cameraIdList
            for (id in cameraIds) {
                val chars = cm.getCameraCharacteristics(id)
                val flashAvailable = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                if (flashAvailable && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    cm.setTorchMode(id, enable)
                    isTorchOn = enable
                    return true
                }
            }
            false
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle torch: ${e.message}", e)
            false
        }
    }

    fun isTorchActive(): Boolean = isTorchOn

    // --- Connectivity Panels (Strictly Excluding Mobile Data) ---

    fun openWifiPanel(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val panelIntent = Intent(Settings.Panel.ACTION_WIFI).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(panelIntent)
            } else {
                val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open Wi-Fi settings: ${e.message}", e)
            false
        }
    }

    fun openBluetoothPanel(): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open Bluetooth settings: ${e.message}", e)
            false
        }
    }

    // --- Global Actions via OrionAccessibilityService ---

    fun lockScreen(): Boolean {
        val service = OrionAccessibilityService.instance
        return service?.lockScreen() ?: false
    }

    fun goHome(): Boolean {
        val service = OrionAccessibilityService.instance
        return service?.goHome() ?: false
    }

    fun goBack(): Boolean {
        val service = OrionAccessibilityService.instance
        return service?.goBack() ?: false
    }

    fun openRecents(): Boolean {
        val service = OrionAccessibilityService.instance
        return service?.openRecents() ?: false
    }

    fun openNotifications(): Boolean {
        val service = OrionAccessibilityService.instance
        return service?.openNotifications() ?: false
    }

    fun scrollUp(): Boolean {
        val service = OrionAccessibilityService.instance
        return service?.scrollUp() ?: false
    }

    fun scrollDown(): Boolean {
        val service = OrionAccessibilityService.instance
        return service?.scrollDown() ?: false
    }

    fun launchAppByPackage(packageName: String): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch app $packageName: ${e.message}", e)
            false
        }
    }

    fun setAlarm(hour: Int, minute: Int, label: String = "Orion Alarm"): Boolean {
        return try {
            val intent = Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(android.provider.AlarmClock.EXTRA_HOUR, hour)
                putExtra(android.provider.AlarmClock.EXTRA_MINUTES, minute)
                putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, label)
                putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set alarm: ${e.message}", e)
            false
        }
    }
}
