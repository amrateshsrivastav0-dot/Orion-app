package com.example.automation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Deep Device Automation Accessibility Service
 * Handles Global Back, Home, Recent Apps, Notifications, and Screen Locking.
 * Also automates WhatsApp contact search and message transmission via node traversal.
 */
class OrionAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "OrionAccessService"
        var instance: OrionAccessibilityService? = null
            private set

        fun isServiceEnabled(context: Context): Boolean {
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val serviceName = "${context.packageName}/${OrionAccessibilityService::class.java.canonicalName}"
            return enabledServices.contains(serviceName, ignoreCase = true)
        }

        fun openAccessibilitySettings(context: Context) {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "Orion Accessibility Service Connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Accessibility events monitored for WhatsApp automated sending if active
        if (event == null) return
        val packageName = event.packageName?.toString() ?: ""
        if (packageName.contains("whatsapp", ignoreCase = true) && pendingWhatsAppMessage != null) {
            tryAutomateWhatsAppMessage()
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "Orion Accessibility Service Interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
        }
    }

    // --- Global Actions ---

    fun lockScreen(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        } else {
            false
        }
    }

    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    fun openRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    fun openNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)

    fun scrollUp(): Boolean {
        val root = rootInActiveWindow ?: return false
        return performScrollAction(root, forward = false)
    }

    fun scrollDown(): Boolean {
        val root = rootInActiveWindow ?: return false
        return performScrollAction(root, forward = true)
    }

    private fun performScrollAction(node: AccessibilityNodeInfo, forward: Boolean): Boolean {
        val action = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        if (node.actionList.any { it.id == action }) {
            return node.performAction(action)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (performScrollAction(child, forward)) {
                return true
            }
        }
        return false
    }

    // --- WhatsApp Automation ---
    private var pendingWhatsAppMessage: String? = null

    fun prepareWhatsAppSend(message: String) {
        pendingWhatsAppMessage = message
    }

    private fun tryAutomateWhatsAppMessage() {
        val message = pendingWhatsAppMessage ?: return
        val root = rootInActiveWindow ?: return

        // Look for input field (EditText)
        val editTexts = mutableListOf<AccessibilityNodeInfo>()
        findNodesByClassName(root, "android.widget.EditText", editTexts)

        if (editTexts.isNotEmpty()) {
            val inputField = editTexts.last()
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, message)
            }
            val textSet = inputField.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            if (textSet) {
                // Find send button
                val sendButtons = mutableListOf<AccessibilityNodeInfo>()
                findSendButton(root, sendButtons)
                if (sendButtons.isNotEmpty()) {
                    sendButtons.first().performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    pendingWhatsAppMessage = null
                }
            }
        }
    }

    private fun findNodesByClassName(node: AccessibilityNodeInfo, className: String, results: MutableList<AccessibilityNodeInfo>) {
        if (node.className?.toString() == className) {
            results.add(node)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findNodesByClassName(child, className, results)
        }
    }

    private fun findSendButton(node: AccessibilityNodeInfo, results: MutableList<AccessibilityNodeInfo>) {
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        val viewId = node.viewIdResourceName?.lowercase() ?: ""
        if (desc.contains("send") || viewId.contains("send")) {
            results.add(node)
            return
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            findSendButton(child, results)
        }
    }

    // --- On-Demand Screen Perception & Vision Actions ---

    data class ScreenAnalysisData(
        val packageName: String,
        val visibleTexts: List<String>,
        val buttons: List<String>,
        val inputFields: List<String>,
        val errorTexts: List<String>,
        val clickableCount: Int
    )

    fun analyzeScreen(): ScreenAnalysisData? {
        val root = rootInActiveWindow ?: return null
        val pkg = root.packageName?.toString() ?: "System"
        val texts = mutableListOf<String>()
        val buttons = mutableListOf<String>()
        val inputs = mutableListOf<String>()
        val errors = mutableListOf<String>()
        var clickables = 0

        fun traverse(node: AccessibilityNodeInfo) {
            val text = node.text?.toString()?.trim()
            val desc = node.contentDescription?.toString()?.trim()
            val className = node.className?.toString() ?: ""
            val isClickable = node.isClickable

            if (isClickable) clickables++

            val label = when {
                !text.isNullOrEmpty() -> text
                !desc.isNullOrEmpty() -> desc
                else -> null
            }

            if (!label.isNullOrEmpty()) {
                if (className.contains("Button", ignoreCase = true) || isClickable) {
                    buttons.add(label)
                } else {
                    texts.add(label)
                }

                val lower = label.lowercase()
                if (lower.contains("error") || lower.contains("invalid") || lower.contains("required") || lower.contains("fail") || lower.contains("warning")) {
                    errors.add(label)
                }
            }

            if (className.contains("EditText", ignoreCase = true)) {
                inputs.add(node.hintText?.toString() ?: label ?: "Input Field")
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                traverse(child)
            }
        }

        traverse(root)
        return ScreenAnalysisData(
            packageName = pkg,
            visibleTexts = texts.take(15),
            buttons = buttons.distinct().take(10),
            inputFields = inputs.distinct().take(5),
            errorTexts = errors.distinct().take(5),
            clickableCount = clickables
        )
    }

    fun clickElementByText(query: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(query)
        for (node in nodes) {
            var curr: AccessibilityNodeInfo? = node
            while (curr != null) {
                if (curr.isClickable) {
                    return curr.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                curr = curr.parent
            }
        }
        // Fallback: search recursively for partial match or content description
        return searchAndClickFuzzy(root, query)
    }

    private fun searchAndClickFuzzy(node: AccessibilityNodeInfo, query: String): Boolean {
        val text = node.text?.toString() ?: ""
        val desc = node.contentDescription?.toString() ?: ""
        if (text.contains(query, ignoreCase = true) || desc.contains(query, ignoreCase = true)) {
            var curr: AccessibilityNodeInfo? = node
            while (curr != null) {
                if (curr.isClickable) {
                    return curr.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                curr = curr.parent
            }
            return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (searchAndClickFuzzy(child, query)) return true
        }
        return false
    }

    /**
     * Self-healing node search: if not visible on screen, scrolls down/up and re-inspects hierarchy
     */
    fun selfHealScrollAndFind(query: String, maxScrolls: Int = 3): Boolean {
        if (clickElementByText(query)) return true
        for (attempt in 1..maxScrolls) {
            val scrolled = scrollDown()
            if (!scrolled) break
            Thread.sleep(300) // Brief UI layout settle
            if (clickElementByText(query)) return true
        }
        // Try scrolling up as alternative healing
        for (attempt in 1..maxScrolls) {
            val scrolled = scrollUp()
            if (!scrolled) break
            Thread.sleep(300)
            if (clickElementByText(query)) return true
        }
        return false
    }

    /**
     * Finds and types text into the primary/focused EditText on screen
     */
    fun typeIntoActiveInput(text: String, submit: Boolean = false): Boolean {
        val root = rootInActiveWindow ?: return false
        val editTexts = mutableListOf<AccessibilityNodeInfo>()
        findNodesByClassName(root, "android.widget.EditText", editTexts)
        if (editTexts.isEmpty()) return false

        val targetInput = editTexts.firstOrNull { it.isFocused } ?: editTexts.last()
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        val textSuccess = targetInput.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        if (textSuccess && submit) {
            val sendButtons = mutableListOf<AccessibilityNodeInfo>()
            findSendButton(root, sendButtons)
            if (sendButtons.isNotEmpty()) {
                sendButtons.first().performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
        }
        return textSuccess
    }

    /**
     * Self-inspects the active window for the most recent message bubble text
     */
    fun inspectLastMessageFromScreen(): String? {
        val root = rootInActiveWindow ?: return null
        val candidates = mutableListOf<String>()

        fun collectTexts(node: AccessibilityNodeInfo) {
            val t = node.text?.toString()?.trim()
            if (!t.isNullOrEmpty() && t.length > 1 && !t.equals("type a message", ignoreCase = true) && !t.contains("search", ignoreCase = true)) {
                candidates.add(t)
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                collectTexts(child)
            }
        }
        collectTexts(root)
        return candidates.lastOrNull()
    }

    fun clickFirstActionableButton(): Boolean {
        val root = rootInActiveWindow ?: return false
        fun search(node: AccessibilityNodeInfo): Boolean {
            if (node.isClickable && (node.className?.contains("Button") == true || !node.text.isNullOrEmpty())) {
                return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                if (search(child)) return true
            }
            return false
        }
        return search(root)
    }
}
