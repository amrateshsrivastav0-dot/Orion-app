package com.example.ambient

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.battery.SmartBatteryMonitor
import com.example.gaming.GamingModeManager
import com.example.notifications.HandsFreeNotificationReader
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Locale

/**
 * Proactive Ambient Context Engine (Zero-Click Anticipation)
 * Continuously evaluates ambient phone telemetry and anticipates actions before the user asks:
 * - Geographical context awareness (transit speed detection, commute vs stationary base)
 * - Silence profiles during night/focus hours
 * - Hands-free notification audio mode when headphones connect
 * - Automated RAM optimization during gaming
 * - Intelligent battery saver profile when low
 */
class AmbientContextEngine(
    private val context: Context,
    private val batteryMonitor: SmartBatteryMonitor,
    private val handsFreeReader: HandsFreeNotificationReader,
    private val gamingManager: GamingModeManager,
    private val onAnticipationTriggered: (AnticipationAction) -> Unit
) {

    companion object {
        private const val TAG = "AmbientContextEngine"
    }

    data class AmbientSnapshot(
        val timeOfDayTag: String,
        val isCharging: Boolean,
        val batteryLevel: Int,
        val isHeadsetPluggedIn: Boolean,
        val isGamingActive: Boolean,
        val suggestedAction: String? = null,
        val activeProfileTag: String = "Balanced",
        val locationTag: String? = null
    )

    data class AnticipationAction(
        val title: String,
        val description: String,
        val actionType: String,
        val autoExecuted: Boolean = true
    )

    private val fusedLocationClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)
    private var lastKnownLocation: Location? = null

    private val _snapshot = MutableStateFlow(
        AmbientSnapshot(
            timeOfDayTag = "Daytime",
            isCharging = false,
            batteryLevel = 100,
            isHeadsetPluggedIn = false,
            isGamingActive = false
        )
    )
    val snapshot: StateFlow<AmbientSnapshot> = _snapshot.asStateFlow()

    private val _latestAnticipation = MutableStateFlow<AnticipationAction?>(null)
    val latestAnticipation: StateFlow<AnticipationAction?> = _latestAnticipation.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Default)
    private var monitorJob: Job? = null

    fun start() {
        if (monitorJob != null) return
        monitorJob = scope.launch {
            while (true) {
                updateLocationContext()
                evaluateAmbientContext()
                delay(10_000) // Poll every 10 seconds for zero-footprint ambient evaluation
            }
        }
    }

    fun stop() {
        monitorJob?.cancel()
        monitorJob = null
    }

    private fun updateLocationContext() {
        val hasFine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasFine && !hasCoarse) return

        try {
            fusedLocationClient.lastLocation
                .addOnSuccessListener { loc: Location? ->
                    if (loc != null) {
                        lastKnownLocation = loc
                    }
                }
                .addOnFailureListener { e ->
                    Log.d(TAG, "Location fetch skipped: ${e.message}")
                }
        } catch (e: SecurityException) {
            Log.w(TAG, "Location permission not granted: ${e.message}")
        }
    }

    private fun evaluateAmbientContext() {
        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)

        val timeTag = when (hour) {
            in 5..8 -> "Early Morning"
            in 9..12 -> "Morning Focus"
            in 13..17 -> "Afternoon Work"
            in 18..21 -> "Evening Leisure"
            else -> "Night Wind-Down"
        }

        val bState = batteryMonitor.batteryState.value
        val isHeadset = handsFreeReader.isHeadsetConnected.value
        val isGaming = gamingManager.isGamingModeActive.value
        val loc = lastKnownLocation

        // Geographical context evaluation: Transit vs Stationary
        val isMovingInTransit = loc != null && loc.hasSpeed() && loc.speed > 4.5f // > ~16 km/h
        val locationTag = when {
            isMovingInTransit -> "Transit (${String.format(Locale.US, "%.0f km/h", loc!!.speed * 3.6f)})"
            loc != null -> "Geo Active"
            else -> null
        }

        var profile = "Balanced System"
        var suggestion: String? = null

        // Anticipation Rule 1: Transit speed detected -> Commute travel mode
        if (isMovingInTransit) {
            profile = "Transit Navigation"
            suggestion = "Commute velocity detected. Hands-free vocal prompts and high-clarity speech armed."
        }
        // Anticipation Rule 2: Gaming mode active -> Auto-optimize RAM & enforce DND
        else if (isGaming) {
            profile = "High-FPS Performance HUD"
            suggestion = "RAM trimmed. Notifications silenced for gaming."
        }
        // Anticipation Rule 3: Night Wind-Down (22:00 - 06:00) + Charging -> Engage Whisper & DND
        else if ((hour >= 22 || hour < 6) && bState.isCharging) {
            profile = "Night Wind-Down"
            suggestion = "Bedside charging detected. Whisper mode & silence profiles engaged."
        }
        // Anticipation Rule 4: Headset connected -> Hands-free voice reading ready
        else if (isHeadset) {
            profile = "Audio Headset Mode"
            suggestion = "Headphones paired: Hands-free vocal announcement armed."
        }
        // Anticipation Rule 5: Battery < 20% -> Suggest battery saver
        else if (bState.level <= 20) {
            profile = "Battery Preservation"
            suggestion = "Battery at ${bState.level}%. Non-essential sensors throttled."
        }

        val newSnapshot = AmbientSnapshot(
            timeOfDayTag = timeTag,
            isCharging = bState.isCharging,
            batteryLevel = bState.level,
            isHeadsetPluggedIn = isHeadset,
            isGamingActive = isGaming,
            suggestedAction = suggestion,
            activeProfileTag = profile,
            locationTag = locationTag
        )

        // Check if suggestion changed to fire anticipation action
        if (suggestion != null && suggestion != _snapshot.value.suggestedAction) {
            val action = AnticipationAction(
                title = profile,
                description = suggestion,
                actionType = profile,
                autoExecuted = true
            )
            _latestAnticipation.value = action
            onAnticipationTriggered(action)
            Log.i(TAG, "Anticipation triggered: $suggestion")
        }

        _snapshot.value = newSnapshot
    }

    fun dismissAnticipation() {
        _latestAnticipation.value = null
    }
}
