package com.example.voice

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Custom Wake-Word Engine with Instant Persistence
 * Supports presets ('Orion', 'Jarvis', 'Friday', 'Nova') and custom wake-words.
 */
class WakeWordEngine(context: Context) {

    companion object {
        private const val PREFS_NAME = "orion_wake_prefs"
        private const val KEY_WAKE_WORD = "active_wake_word"
        val PRESETS = listOf("Orion", "Jarvis", "Friday", "Nova")
    }

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _activeWakeWord = MutableStateFlow(
        prefs.getString(KEY_WAKE_WORD, "Orion") ?: "Orion"
    )
    val activeWakeWord: StateFlow<String> = _activeWakeWord.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    fun pause() {
        _isPaused.value = true
    }

    fun resume() {
        _isPaused.value = false
    }

    fun setWakeWord(name: String) {
        val clean = name.trim().ifEmpty { "Orion" }
        prefs.edit().putString(KEY_WAKE_WORD, clean).apply()
        _activeWakeWord.value = clean
    }

    /**
     * Checks if recognized speech contains the active wake word.
     */
    fun matchesWakeWord(text: String): Boolean {
        if (_isPaused.value) return false
        val word = _activeWakeWord.value.lowercase()
        val input = text.lowercase()
        return input.contains(word) || (word == "orion" && (input.contains("orion") || input.contains("orian") || input.contains("aryan")))
    }

    /**
     * Strips wake word from the input command.
     */
    fun cleanCommand(text: String): String {
        val word = _activeWakeWord.value
        return text.replace(Regex("(?i)^.*?(hey|ok|hello)?\\s*$word[,\\s]*"), "").trim()
    }
}
