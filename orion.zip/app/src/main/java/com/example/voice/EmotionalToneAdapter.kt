package com.example.voice

import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Emotional Tone & Speech Cadence Adaptation Engine
 * Analyzes speech cadence, urgency indicators, and sentiment to dynamically modulate
 * voice pacing, response brevity, and pitch (Calm, Fast/Urgent, Focused, Balanced).
 */
class EmotionalToneAdapter {

    companion object {
        private const val TAG = "EmotionalToneAdapter"
    }

    enum class EmotionalUrgency(
        val label: String,
        val pacingMultiplier: Float,
        val pitchMultiplier: Float,
        val maxWordsInResponse: Int
    ) {
        URGENT("Rapid Tactical", 1.25f, 1.05f, 25),
        FOCUSED("Focused Sharp", 1.10f, 1.00f, 40),
        CALM("Soothing Composed", 0.92f, 0.95f, 60),
        BALANCED("Natural Fluid", 1.00f, 1.00f, 50)
    }

    private val _currentUrgency = MutableStateFlow(EmotionalUrgency.BALANCED)
    val currentUrgency: StateFlow<EmotionalUrgency> = _currentUrgency.asStateFlow()

    private val urgentKeywords = listOf(
        "quick", "fast", "hurry", "urgent", "emergency", "jaldi", "asap",
        "now", "immediately", "turant", "danger", "late", "run"
    )

    private val calmKeywords = listOf(
        "relax", "calm", "slowly", "peaceful", "shanti", "aaram se",
        "gentle", "quiet", "softly", "bedtime", "story"
    )

    private val focusedKeywords = listOf(
        "briefing", "report", "data", "status", "execute", "task",
        "confirm", "verify", "step", "summary"
    )

    /**
     * Evaluates user input string and duration in milliseconds to deduce emotional urgency.
     */
    fun analyzeSpeechInput(text: String, speechDurationMs: Long = 0L): EmotionalUrgency {
        val lower = text.lowercase().trim()
        val wordCount = lower.split(Regex("\\s+")).filter { it.isNotEmpty() }.size

        // 1. Keyword-based sentiment matching
        val hasUrgentKeyword = urgentKeywords.any { lower.contains(it) }
        val hasCalmKeyword = calmKeywords.any { lower.contains(it) }
        val hasFocusedKeyword = focusedKeywords.any { lower.contains(it) }

        // 2. Speech cadence calculation (words per minute if duration is provided)
        val wpm = if (speechDurationMs > 500L) {
            (wordCount * 60_000L) / speechDurationMs
        } else 0L

        val detected = when {
            hasUrgentKeyword || wpm > 220 -> EmotionalUrgency.URGENT
            hasCalmKeyword -> EmotionalUrgency.CALM
            hasFocusedKeyword || wordCount in 1..4 -> EmotionalUrgency.FOCUSED
            else -> EmotionalUrgency.BALANCED
        }

        _currentUrgency.value = detected
        Log.i(TAG, "Analyzed emotional state: ${detected.label} (wpm=$wpm, words=$wordCount)")
        return detected
    }

    /**
     * Dynamically trims or adjusts speech text to suit the emotional state's brevity threshold.
     */
    fun adaptResponseText(text: String, state: EmotionalUrgency = _currentUrgency.value): String {
        if (state == EmotionalUrgency.URGENT) {
            // Cut down to the primary actionable sentence
            val firstSentence = text.split(Regex("[.!?]\\s+")).firstOrNull() ?: text
            return firstSentence.trim()
        }
        return text
    }
}
