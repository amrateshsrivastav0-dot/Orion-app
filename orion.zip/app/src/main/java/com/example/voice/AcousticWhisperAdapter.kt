package com.example.voice

import android.content.Context
import android.media.AudioManager
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Calendar

/**
 * Acoustic Whisper & Dynamic Volume Adaptation Engine
 * Measures ambient noise levels (SPL/RMS dB) before speaking.
 * If user whispers or environment is dead-silent (or late night), responds in a low, gentle whisper tone.
 * If high ambient noise is detected, boosts speech gain and clarity.
 */
class AcousticWhisperAdapter(private val context: Context) {

    companion object {
        private const val TAG = "AcousticWhisperAdapter"
    }

    enum class AcousticMode(val label: String, val badge: String) {
        WHISPER("Whisper Mode (Gentle/Low Tone)", "🌙 WHISPER"),
        NORMAL("Acoustic Standard (Balanced)", "🎙️ BALANCED"),
        HIGH_NOISE_BOOST("Gain Boost (High Noise Environment)", "🔊 HIGH GAIN")
    }

    data class AcousticProfile(
        val mode: AcousticMode,
        val volumeMultiplier: Float,
        val pitchMultiplier: Float,
        val pacingMultiplier: Float,
        val ambientDbEstimate: Float
    )

    private val _currentMode = MutableStateFlow(AcousticMode.NORMAL)
    val currentMode: StateFlow<AcousticMode> = _currentMode.asStateFlow()

    private val _lastAmbientDb = MutableStateFlow(8f)
    val lastAmbientDb: StateFlow<Float> = _lastAmbientDb.asStateFlow()

    /**
     * Determines the optimal speech acoustic profile based on ambient noise level and time of day
     */
    fun evaluateAcousticProfile(recentRmsDb: Float): AcousticProfile {
        _lastAmbientDb.value = recentRmsDb

        val cal = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val isLateNight = hour >= 23 || hour < 6

        val profile = when {
            // Whisper condition: Dead-silent room (< 4.0 dB) or late night hours with soft input (< 7.0 dB)
            recentRmsDb < 3.5f || (isLateNight && recentRmsDb < 7.0f) -> {
                AcousticProfile(
                    mode = AcousticMode.WHISPER,
                    volumeMultiplier = 0.38f,
                    pitchMultiplier = 0.88f,
                    pacingMultiplier = 0.90f,
                    ambientDbEstimate = recentRmsDb
                )
            }
            // High noise boost: Loud ambient environment (> 18.0 dB)
            recentRmsDb > 18.0f -> {
                AcousticProfile(
                    mode = AcousticMode.HIGH_NOISE_BOOST,
                    volumeMultiplier = 1.0f,
                    pitchMultiplier = 1.15f,
                    pacingMultiplier = 1.05f,
                    ambientDbEstimate = recentRmsDb
                )
            }
            // Standard balanced indoor acoustic
            else -> {
                AcousticProfile(
                    mode = AcousticMode.NORMAL,
                    volumeMultiplier = 0.90f,
                    pitchMultiplier = 1.00f,
                    pacingMultiplier = 1.00f,
                    ambientDbEstimate = recentRmsDb
                )
            }
        }

        _currentMode.value = profile.mode
        Log.d(TAG, "Acoustic mode evaluated: ${profile.mode.name} (RMS: $recentRmsDb dB, vol: ${profile.volumeMultiplier})")
        return profile
    }
}
