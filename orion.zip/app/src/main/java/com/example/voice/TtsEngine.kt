package com.example.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * Native High-Fidelity Multi-Voice TTS Engine
 * Supports Jarvis (deep baritone), Nova (conversational tone), and Orion (clear assistant).
 */
class TtsEngine(context: Context) {

    companion object {
        private const val TAG = "TtsEngine"
    }

    enum class VoiceProfile(val label: String, val pitch: Float, val speechRate: Float) {
        ORION("Orion (Crisp AI Assistant)", 1.00f, 1.00f),
        JARVIS("Jarvis (Deep Baritone)", 0.72f, 0.94f),
        NOVA("Nova (Warm Conversational)", 1.18f, 1.05f)
    }

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _currentProfile = MutableStateFlow(VoiceProfile.ORION)
    val currentProfile: StateFlow<VoiceProfile> = _currentProfile.asStateFlow()

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isInitialized = true
                applyProfile(_currentProfile.value)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _isSpeaking.value = true
                    }

                    override fun onDone(utteranceId: String?) {
                        _isSpeaking.value = false
                    }

                    override fun onError(utteranceId: String?) {
                        _isSpeaking.value = false
                    }
                })
            } else {
                Log.e(TAG, "TTS Initialization failed: $status")
            }
        }
    }

    fun setProfile(profile: VoiceProfile) {
        _currentProfile.value = profile
        applyProfile(profile)
    }

    private fun applyProfile(profile: VoiceProfile) {
        tts?.let { engine ->
            engine.setPitch(profile.pitch)
            engine.setSpeechRate(profile.speechRate)
            // Try Indian English or fallback to Default/US
            val inLocale = Locale("en", "IN")
            val available = engine.isLanguageAvailable(inLocale)
            if (available >= TextToSpeech.LANG_AVAILABLE) {
                engine.language = inLocale
            } else {
                engine.language = Locale.getDefault()
            }
        }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        speakWithModulation(text, 1.0f, 1.0f, 1.0f, onDone)
    }

    fun speakWithModulation(
        text: String,
        pacingMultiplier: Float = 1.0f,
        pitchMultiplier: Float = 1.0f,
        volumeMultiplier: Float = 1.0f,
        onDone: (() -> Unit)? = null
    ) {
        if (!isInitialized) return
        _isSpeaking.value = true
        val utteranceId = "orion_${System.currentTimeMillis()}"
        val base = _currentProfile.value
        tts?.let { engine ->
            engine.setPitch(base.pitch * pitchMultiplier)
            engine.setSpeechRate(base.speechRate * pacingMultiplier)
            val inLocale = Locale("en", "IN")
            if (engine.isLanguageAvailable(inLocale) >= TextToSpeech.LANG_AVAILABLE) {
                engine.language = inLocale
            } else {
                engine.language = Locale.getDefault()
            }
            val params = android.os.Bundle().apply {
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volumeMultiplier.coerceIn(0.15f, 1.0f))
            }
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        }
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
