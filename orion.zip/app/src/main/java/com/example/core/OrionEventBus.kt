package com.example.core

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * High-Performance, Zero-Leak Asynchronous EventBus
 * Backed by Kotlin Coroutine SharedFlow with strict buffer limits (replay = 0, extraBufferCapacity = 64)
 * to prevent memory leaks and thread contention, maintaining 60+ FPS UI rendering.
 */
object OrionEventBus {

    sealed class Event {
        data class SystemStatus(val message: String, val level: Int = 0) : Event()
        data class ReActUpdate(val step: Int, val total: Int, val description: String) : Event()
        data class AcousticUpdate(val mode: String, val db: Float) : Event()
        data class BrainCoreUsed(val tierName: String, val latencyMs: Long) : Event()
        data class AnticipationAlert(val title: String, val suggestion: String) : Event()
        data class MemoryStored(val key: String, val content: String) : Event()
    }

    private val _events = MutableSharedFlow<Event>(
        replay = 0,
        extraBufferCapacity = 64,
        onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST
    )
    val events: SharedFlow<Event> = _events.asSharedFlow()

    fun emit(event: Event) {
        _events.tryEmit(event)
    }
}
