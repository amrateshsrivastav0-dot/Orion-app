package com.example.memory

import android.content.Context
import kotlinx.coroutines.flow.Flow
import java.util.Locale

class MemoryRepository(context: Context) {

    private val database = OrionDatabase.getInstance(context)
    private val memoryDao = database.memoryDao()

    val allMemories: Flow<List<MemoryEntity>> = memoryDao.getAllMemories()

    suspend fun saveMemory(key: String, content: String, category: String = "GENERAL"): Long {
        val entity = MemoryEntity(
            memoryKey = key.trim(),
            content = content.trim(),
            category = category
        )
        return memoryDao.insertMemory(entity)
    }

    suspend fun queryMemory(query: String): String? {
        val clean = query.lowercase(Locale.ROOT)
            .replace("what did i tell you about", "")
            .replace("what is my", "")
            .replace("where is my", "")
            .replace("tell me about", "")
            .replace("kahan hai", "")
            .replace("kya hai", "")
            .replace("yaad dilao", "")
            .trim()

        val found = memoryDao.findMemoryByKey(clean)
        return found?.content
    }

    suspend fun deleteMemory(id: Long) {
        memoryDao.deleteMemoryById(id)
    }

    suspend fun clearAll() {
        memoryDao.clearAllMemories()
    }

    /**
     * Checks if query is a memory command ("Orion, remember that..." or "Orion, yaad rakhna...")
     */
    fun isStoreMemoryCommand(query: String): Boolean {
        val lower = query.lowercase(Locale.ROOT)
        return lower.contains("remember that") ||
                lower.contains("remember this") ||
                lower.contains("note that") ||
                lower.contains("yaad rakhna ki") ||
                lower.contains("yaad rakhna") ||
                lower.contains("save note")
    }

    /**
     * Checks if query is a recall command ("Orion, what did I tell you about...", "Orion, yaad hai...")
     */
    fun isRecallMemoryCommand(query: String): Boolean {
        val lower = query.lowercase(Locale.ROOT)
        return lower.contains("what did i tell you") ||
                lower.contains("what is my") ||
                lower.contains("where did i") ||
                lower.contains("where is my") ||
                lower.contains("do you remember") ||
                lower.contains("yaad hai") ||
                lower.contains("kahan rakha tha") ||
                lower.contains("kya tha mera") ||
                lower.contains("saved notes") ||
                lower.contains("all memories")
    }

    /**
     * Extracts key and content from store command.
     */
    fun parseMemoryInput(input: String): Pair<String, String> {
        val lower = input.lowercase(Locale.ROOT)
        var text = input

        val prefixes = listOf(
            "remember that", "remember this", "remember",
            "yaad rakhna ki", "yaad rakhna",
            "note that", "save this"
        )
        for (prefix in prefixes) {
            val idx = lower.indexOf(prefix)
            if (idx >= 0) {
                text = input.substring(idx + prefix.length).trim()
                break
            }
        }

        // Try extracting key if contains "is" or "hai"
        val isIdx = text.lowercase(Locale.ROOT).indexOf(" is ")
        val haiIdx = text.lowercase(Locale.ROOT).indexOf(" hai")

        return if (isIdx > 0) {
            val key = text.substring(0, isIdx).trim()
            val content = text.substring(isIdx + 4).trim()
            Pair(key, text)
        } else if (haiIdx > 0) {
            val key = text.substring(0, haiIdx).trim()
            Pair(key, text)
        } else {
            val words = text.split(" ")
            val key = words.take(3).joinToString(" ")
            Pair(key, text)
        }
    }
}
