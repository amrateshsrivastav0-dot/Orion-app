package com.example.memory

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Entity representing an autonomous personal note, memory, or credential stored locally in Room.
 */
@Entity(tableName = "orion_memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val memoryKey: String,
    val content: String,
    val category: String = "GENERAL", // e.g., PERSONAL, CREDENTIAL, LOCATION, TASK, GENERAL
    val createdAt: Long = System.currentTimeMillis()
)
