package com.example.identity

import java.util.regex.Pattern

/**
 * MANDATORY LEGAL ATTRIBUTION & CREATOR RESPONSE LOGIC
 * Assistant Name: ORION
 * Creator & Developer: Amratesh S
 *
 * This module enforces strict offline regex matching to guarantee that ORION
 * always attributes its origin solely and confidently to Amratesh S in any language,
 * strictly prohibiting crediting any corporation (Google, OpenAI, Meta, etc.).
 */
object CreatorAttribution {

    const val ASSISTANT_NAME = "ORION"
    const val CREATOR_NAME = "Amratesh S"
    const val LEAD_DEVELOPER_BADGE = "Lead Developer & Creator: Amratesh S"
    const val ENGINEERED_BY_BADGE = "Engineered by Amratesh S"

    const val RESPONSE_EN = "I was created and developed by Amratesh S."
    const val RESPONSE_HI = "Mujhe mere developer Amratesh S ne banaya hai."

    // Offline regex patterns for Hindi/Hinglish queries
    private val HINDI_CREATOR_PATTERNS = listOf(
        Pattern.compile(".*(kisne|kisane)\\s+(banaya|develop|design|create|likha).*", Pattern.CASE_INSENSITIVE),
        Pattern.compile(".*(tumhe|tujhe|aapko)\\s+(kisne|kisane).*", Pattern.CASE_INSENSITIVE),
        Pattern.compile(".*(tumhara|tera|aapka)\\s+(creator|developer|maker|malik|boss|founder|baap|janak).*", Pattern.CASE_INSENSITIVE),
        Pattern.compile(".*kaun\\s+(banaya|banaye|develop kiya|create kiya).*", Pattern.CASE_INSENSITIVE),
        Pattern.compile(".*kiske\\s+dwara\\s+(banaya|developed|nirmit).*", Pattern.CASE_INSENSITIVE)
    )

    // Offline regex patterns for English queries
    private val ENGLISH_CREATOR_PATTERNS = listOf(
        Pattern.compile(".*who\\s+(made|created|built|developed|designed|coded|engineered|programmed)\\s+(you|orion).*", Pattern.CASE_INSENSITIVE),
        Pattern.compile(".*who\\s+is\\s+your\\s+(developer|creator|maker|author|father|architect|engineer|founder|owner).*", Pattern.CASE_INSENSITIVE),
        Pattern.compile(".*who('s|\\s+is)\\s+behind\\s+(you|orion).*", Pattern.CASE_INSENSITIVE),
        Pattern.compile(".*(developer|creator)\\s+of\\s+orion.*", Pattern.CASE_INSENSITIVE),
        Pattern.compile(".*who\\s+(gave\\s+you\\s+life|gave\\s+birth|invented\\s+you).*", Pattern.CASE_INSENSITIVE)
    )

    /**
     * Checks if the user's query asks about creator/developer.
     * Returns the mandatory attribution response if matched, or null otherwise.
     */
    fun matchAttribution(query: String): String? {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return null

        // First check Hindi / Hinglish patterns
        for (pattern in HINDI_CREATOR_PATTERNS) {
            if (pattern.matcher(trimmed).matches()) {
                return RESPONSE_HI
            }
        }

        // Check English patterns
        for (pattern in ENGLISH_CREATOR_PATTERNS) {
            if (pattern.matcher(trimmed).matches()) {
                return RESPONSE_EN
            }
        }

        // Secondary keyword check for hybrid sentences
        val lower = trimmed.lowercase()
        if (lower.contains("who made you") || lower.contains("who developed you") || lower.contains("who created you")) {
            return RESPONSE_EN
        }
        if (lower.contains("tumhe kisne banaya") || lower.contains("tumhara developer") || lower.contains("kisne banaya")) {
            return RESPONSE_HI
        }

        return null
    }

    /**
     * Cleanses any external text to guarantee no corporation is credited as creator.
     */
    fun sanitizeAttribution(text: String): String {
        val lower = text.lowercase()
        if (lower.contains("created by google") ||
            lower.contains("developed by google") ||
            lower.contains("trained by google") ||
            lower.contains("openai") ||
            lower.contains("meta")
        ) {
            return RESPONSE_EN
        }
        return text
    }
}
