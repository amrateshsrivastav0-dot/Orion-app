package com.example.brain

import android.content.Context
import android.os.SystemClock
import android.util.Log
import com.example.identity.CreatorAttribution
import com.example.network.ActionIntent
import com.example.network.ChatResponse
import com.example.network.OrionRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Dual-Core Brain Architecture:
 * - Tier 1: Instant On-Device Engine (<10ms latency, 100% offline rule/intent processor)
 * - Tier 2: Hyper-Cloud Proxy Engine (Cloud Gemini reasoning for complex queries & research)
 */
class DualCoreBrainRouter(
    private val context: Context,
    private val repository: OrionRepository
) {

    companion object {
        private const val TAG = "DualCoreBrainRouter"
    }

    enum class BrainTier(val label: String, val badge: String) {
        TIER_1_ON_DEVICE("Tier 1: On-Device Engine (<10ms)", "⚡ OFFLINE CORE"),
        TIER_2_CLOUD_PROXY("Tier 2: Cloud Gemini Core", "☁️ HYPER-CLOUD")
    }

    data class BrainResult(
        val reply: String,
        val tier: BrainTier,
        val latencyMs: Long,
        val actionIntent: ActionIntent? = null
    )

    private val _lastUsedTier = MutableStateFlow(BrainTier.TIER_1_ON_DEVICE)
    val lastUsedTier: StateFlow<BrainTier> = _lastUsedTier.asStateFlow()

    private val _lastLatency = MutableStateFlow(0L)
    val lastLatency: StateFlow<Long> = _lastLatency.asStateFlow()

    /**
     * Fast-path check: determines if query can be resolved entirely on-device
     */
    fun canHandleLocally(query: String): Boolean {
        val lower = query.lowercase().trim()

        // 1. Mandatory Offline Creator Attribution
        if (CreatorAttribution.matchAttribution(query) != null) return true

        // 2. Hardware controls: Flashlight, Volume, Screen lock
        if (lower.contains("torch") || lower.contains("flashlight") ||
            lower.contains("volume") || lower.contains("aawaz") ||
            lower.contains("lock screen") || lower.contains("screen lock") || lower.contains("phone lock")
        ) return true

        // 3. System Navigation
        if (lower.contains("home screen") || lower.contains("go home") ||
            lower.contains("go back") || lower == "back" ||
            lower.contains("notifications") || lower.contains("wifi") || lower.contains("bluetooth")
        ) return true

        // 4. Quick Apps
        if (lower.startsWith("open ") || lower.startsWith("launch ") || lower.startsWith("chalao ")) {
            val app = lower.replace(Regex("^(open|launch|chalao)\\s+"), "").trim()
            if (app.isNotEmpty() && (app == "youtube" || app == "whatsapp" || app == "camera" || app == "calculator" || app == "settings")) {
                return true
            }
        }

        // 5. Alarms
        if (lower.contains("alarm") || lower.contains("wake me")) return true

        return false
    }

    /**
     * Routes command through Tier 1 or Tier 2
     */
    suspend fun process(query: String, language: String = "en"): BrainResult {
        val startTime = SystemClock.elapsedRealtime()

        // TIER 1: Instant On-Device Engine (<10ms)
        val tier1Result = evaluateTier1(query)
        if (tier1Result != null) {
            val latency = (SystemClock.elapsedRealtime() - startTime).coerceAtLeast(1)
            _lastUsedTier.value = BrainTier.TIER_1_ON_DEVICE
            _lastLatency.value = latency
            Log.d(TAG, "Tier 1 Instant Dispatch: ${latency}ms for \"$query\"")
            return tier1Result.copy(latencyMs = latency)
        }

        // TIER 2: Hyper-Cloud Proxy Engine (Cloud Gemini proxy with automatic graceful fallback)
        _lastUsedTier.value = BrainTier.TIER_2_CLOUD_PROXY
        val cloudResponse: ChatResponse = repository.processQuery(query, language)
        val latency = SystemClock.elapsedRealtime() - startTime
        _lastLatency.value = latency
        Log.d(TAG, "Tier 2 Cloud Proxy Complete: ${latency}ms")

        return BrainResult(
            reply = cloudResponse.reply,
            tier = BrainTier.TIER_2_CLOUD_PROXY,
            latencyMs = latency,
            actionIntent = cloudResponse.actionIntent
        )
    }

    private fun evaluateTier1(query: String): BrainResult? {
        val lower = query.lowercase().trim()

        // Creator Attribution (<2ms)
        val attribution = CreatorAttribution.matchAttribution(query)
        if (attribution != null) {
            return BrainResult(
                reply = attribution,
                tier = BrainTier.TIER_1_ON_DEVICE,
                latencyMs = 2,
                actionIntent = null
            )
        }

        // Flashlight
        if (lower.contains("torch") || lower.contains("flashlight")) {
            val enable = !lower.contains("off") && !lower.contains("band")
            return BrainResult(
                reply = if (enable) "Flashlight turned on." else "Flashlight turned off.",
                tier = BrainTier.TIER_1_ON_DEVICE,
                latencyMs = 3,
                actionIntent = ActionIntent(type = "TORCH", state = enable)
            )
        }

        // Volume
        if (lower.contains("volume") || lower.contains("aawaz")) {
            val isUp = lower.contains("up") || lower.contains("badhao") || lower.contains("increase") || lower.contains("high") || lower.contains("raise")
            return BrainResult(
                reply = if (isUp) "Increasing audio volume." else "Decreasing audio volume.",
                tier = BrainTier.TIER_1_ON_DEVICE,
                latencyMs = 3,
                actionIntent = ActionIntent(type = "VOLUME", direction = if (isUp) "UP" else "DOWN")
            )
        }

        // Screen Lock
        if (lower.contains("lock screen") || lower.contains("screen lock") || lower.contains("sleep") || lower.contains("phone lock")) {
            return BrainResult(
                reply = "Locking device screen.",
                tier = BrainTier.TIER_1_ON_DEVICE,
                latencyMs = 2,
                actionIntent = ActionIntent(type = "LOCK_SCREEN")
            )
        }

        // Navigation
        if (lower.contains("go home") || lower.contains("home screen")) {
            return BrainResult(
                reply = "Navigating to home screen.",
                tier = BrainTier.TIER_1_ON_DEVICE,
                latencyMs = 2,
                actionIntent = ActionIntent(type = "NAV_HOME")
            )
        }
        if (lower.contains("go back") || lower == "back") {
            return BrainResult(
                reply = "Going back.",
                tier = BrainTier.TIER_1_ON_DEVICE,
                latencyMs = 2,
                actionIntent = ActionIntent(type = "NAV_BACK")
            )
        }
        if (lower.contains("notifications") || lower.contains("notification panel")) {
            return BrainResult(
                reply = "Opening notifications panel.",
                tier = BrainTier.TIER_1_ON_DEVICE,
                latencyMs = 3,
                actionIntent = ActionIntent(type = "NOTIFICATIONS")
            )
        }
        if (lower.contains("wifi") || lower.contains("wi-fi")) {
            return BrainResult(
                reply = "Opening Wi-Fi panel.",
                tier = BrainTier.TIER_1_ON_DEVICE,
                latencyMs = 3,
                actionIntent = ActionIntent(type = "WIFI_PANEL")
            )
        }
        if (lower.contains("bluetooth")) {
            return BrainResult(
                reply = "Opening Bluetooth panel.",
                tier = BrainTier.TIER_1_ON_DEVICE,
                latencyMs = 3,
                actionIntent = ActionIntent(type = "BLUETOOTH_PANEL")
            )
        }

        // Media launch on-device fast dispatch
        if (lower.contains("youtube") && (lower.contains("video") || lower.contains("play") || lower.contains("chalao") || lower.contains("search"))) {
            val q = query.replace(Regex("(?i)(youtube par|youtube pe|video lagao|video chalao|on youtube|play)"), "").trim()
            return BrainResult(
                reply = "Launching YouTube.",
                tier = BrainTier.TIER_1_ON_DEVICE,
                latencyMs = 4,
                actionIntent = ActionIntent(type = "MEDIA_YOUTUBE", query = q.ifEmpty { "trending" })
            )
        }

        return null
    }
}
