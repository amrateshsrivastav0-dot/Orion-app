package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ambient.AmbientContextEngine
import com.example.automation.ChainedActionPlanner
import com.example.automation.DeviceController
import com.example.automation.MediaBrain
import com.example.automation.OrionAccessibilityService
import com.example.automation.ReActAgentEngine
import com.example.battery.SmartBatteryMonitor
import com.example.brain.DualCoreBrainRouter
import com.example.core.OrionEventBus
import com.example.gaming.GamingModeManager
import com.example.identity.CreatorAttribution
import com.example.memory.MemoryEntity
import com.example.memory.MemoryRepository
import com.example.network.OrionRepository
import com.example.notifications.HandsFreeNotificationReader
import com.example.notifications.OrionNotificationListenerService
import com.example.research.AutonomousResearchBrain
import com.example.scheduler.ScheduledTaskDispatcher
import com.example.sensors.PocketGuardManager
import com.example.telecom.SmartCallManager
import com.example.vision.AirGestureDetector
import com.example.vision.ScreenPerceptionAgent
import com.example.voice.AcousticWhisperAdapter
import com.example.voice.EmotionalToneAdapter
import com.example.voice.SpeechEngine
import com.example.voice.TtsEngine
import com.example.voice.WakeWordEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class OrionViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "OrionViewModel"
    }

    val repository = OrionRepository(application)
    val speechEngine = SpeechEngine(application)
    val ttsEngine = TtsEngine(application)
    val wakeWordEngine = WakeWordEngine(application)
    val deviceController = DeviceController(application)
    val mediaBrain = MediaBrain(application)
    val callManager = SmartCallManager.init(application)
    val airGestureDetector = AirGestureDetector(application)

    // Autonomous Cognitive & Utility Engines
    val chainedActionPlanner = ChainedActionPlanner(application, deviceController, mediaBrain)
    val screenPerceptionAgent = ScreenPerceptionAgent(application)
    val researchBrain = AutonomousResearchBrain(application)
    val emotionalToneAdapter = EmotionalToneAdapter()
    val acousticWhisperAdapter = AcousticWhisperAdapter(application)
    val dualCoreBrainRouter = DualCoreBrainRouter(application, repository)
    val reactAgentEngine = ReActAgentEngine(application, deviceController, mediaBrain, screenPerceptionAgent)

    // Autonomous Utility Engines (Memory, Gaming, Battery, Scheduler, Sensors, Headset)
    val memoryRepository = MemoryRepository(application)
    val gamingModeManager = GamingModeManager(application)
    val scheduledTaskDispatcher = ScheduledTaskDispatcher(application)
    val pocketGuardManager = PocketGuardManager(application) { inPocket ->
        if (inPocket) {
            wakeWordEngine.pause()
            _assistantReply.value = "Pocket Guard Active: Device enclosed. Listening & touch input paused."
        } else {
            wakeWordEngine.resume()
            _assistantReply.value = "Pocket Guard: Sensors clear. Active listening resumed."
        }
    }
    val handsFreeReader = HandsFreeNotificationReader(application) { announceText ->
        speakResponse(announceText, "headset")
    }
    val batteryMonitor = SmartBatteryMonitor(application) { batteryAlert ->
        speakResponse(batteryAlert, "battery")
    }
    val ambientContextEngine = AmbientContextEngine(
        application,
        batteryMonitor,
        handsFreeReader,
        gamingModeManager
    ) { anticipation ->
        OrionEventBus.emit(OrionEventBus.Event.AnticipationAlert(anticipation.title, anticipation.description))
    }

    // UI States
    private val _assistantState = MutableStateFlow(AssistantState.IDLE)
    val assistantState: StateFlow<AssistantState> = _assistantState.asStateFlow()

    private val _currentTheme = MutableStateFlow(OrbThemePreset.CYBER_OBSIDIAN)
    val currentTheme: StateFlow<OrbThemePreset> = _currentTheme.asStateFlow()

    private val _userTranscript = MutableStateFlow("")
    val userTranscript: StateFlow<String> = _userTranscript.asStateFlow()

    private val _assistantReply = MutableStateFlow("I am ORION. Say 'Orion' or tap mic to begin.")
    val assistantReply: StateFlow<String> = _assistantReply.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _isGesturesEnabled = MutableStateFlow(true)
    val isGesturesEnabled: StateFlow<Boolean> = _isGesturesEnabled.asStateFlow()

    private val _lastGestureEvent = MutableStateFlow<String?>(null)
    val lastGestureEvent: StateFlow<String?> = _lastGestureEvent.asStateFlow()

    private val _showCustomizationSheet = MutableStateFlow(false)
    val showCustomizationSheet: StateFlow<Boolean> = _showCustomizationSheet.asStateFlow()

    private val _activePerceptionCard = MutableStateFlow<ScreenPerceptionAgent.PerceptionResult?>(null)
    val activePerceptionCard: StateFlow<ScreenPerceptionAgent.PerceptionResult?> = _activePerceptionCard.asStateFlow()

    private val _notificationScreenerEnabled = MutableStateFlow(true)
    val notificationScreenerEnabled: StateFlow<Boolean> = _notificationScreenerEnabled.asStateFlow()

    init {
        setupSpeechEngine()
        pocketGuardManager.start()
        handsFreeReader.start()
        batteryMonitor.startListening()
        ambientContextEngine.start()

        // Observe screened urgent notifications and dispatch to hands-free headset reader
        viewModelScope.launch {
            OrionNotificationListenerService.latestUrgentNotification.collect { notif ->
                if (notif != null) {
                    handsFreeReader.onScreenedNotificationReceived(notif)
                }
            }
        }
    }

    private fun setupSpeechEngine() {
        speechEngine.initialize()

        speechEngine.onResult = { text ->
            _userTranscript.value = text
            handleSpokenInput(text)
        }

        speechEngine.onError = { error ->
            Log.w(TAG, "Speech recognition error: $error")
            _assistantState.value = AssistantState.IDLE
        }
    }

    fun setTheme(theme: OrbThemePreset) {
        _currentTheme.value = theme
    }

    fun setVoiceProfile(profile: TtsEngine.VoiceProfile) {
        ttsEngine.setProfile(profile)
    }

    fun setWakeWord(word: String) {
        wakeWordEngine.setWakeWord(word)
    }

    fun toggleMute() {
        _isMuted.value = !_isMuted.value
        if (_isMuted.value) {
            ttsEngine.stop()
        }
    }

    fun toggleCustomizationSheet(show: Boolean) {
        _showCustomizationSheet.value = show
    }

    fun toggleAirGestures(enabled: Boolean) {
        _isGesturesEnabled.value = enabled
        if (!enabled) {
            airGestureDetector.pause()
        }
    }

    fun toggleMic() {
        if (speechEngine.isListening.value) {
            speechEngine.stopListening()
            _assistantState.value = AssistantState.IDLE
        } else {
            ttsEngine.stop()
            _assistantState.value = AssistantState.LISTENING
            speechEngine.startListening()
        }
    }

    fun submitTextQuery(query: String) {
        _userTranscript.value = query
        processCommand(query)
    }

    private fun handleSpokenInput(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) {
            _assistantState.value = AssistantState.IDLE
            return
        }

        // Check if ringing call voice trigger ("Orion, pick up")
        if (callManager.callState.value == SmartCallManager.CallState.RINGING) {
            val lower = trimmed.lowercase()
            if (lower.contains("pick up") || lower.contains("answer") || lower.contains("uthayo") || lower.contains("receive")) {
                callManager.answerCallWithSpeaker { status ->
                    speakResponse(status)
                }
                return
            }
        }

        // Clean wake word if present
        val cleaned = wakeWordEngine.cleanCommand(trimmed)
        val finalQuery = if (cleaned.isNotBlank()) cleaned else trimmed
        processCommand(finalQuery)
    }

    fun processCommand(query: String) {
        _assistantState.value = AssistantState.PROCESSING

        viewModelScope.launch {
            // Step 1: Mandatory Offline Creator Attribution check
            val offlineAttribution = CreatorAttribution.matchAttribution(query)
            if (offlineAttribution != null) {
                _assistantReply.value = offlineAttribution
                speakResponse(offlineAttribution, query)
                return@launch
            }

            // Step 2: Autonomous Self-Healing Agent Loop (Goal-Driven Execution)
            if (reactAgentEngine.isReActGoal(query)) {
                val startAck = "Engaging Autonomous ReAct Agent Loop. Decomposing goal and monitoring UI hierarchy."
                _assistantReply.value = startAck
                speakResponse(startAck, query)

                reactAgentEngine.executeGoal(
                    goal = query,
                    onProgress = { progress ->
                        _assistantReply.value = progress
                    },
                    onComplete = { completion ->
                        _assistantReply.value = completion
                        speakResponse(completion, "completed")
                    }
                )
                return@launch
            }

            // Step 3: On-Demand Screen Perception (Vision Agent)
            if (screenPerceptionAgent.isScreenPerceptionCommand(query)) {
                val perception = screenPerceptionAgent.perceiveScreen()
                _activePerceptionCard.value = perception
                _assistantReply.value = perception.summary

                // Auto-action if user commanded "karo", "tap karo", "daba do"
                val lower = query.lowercase()
                if (lower.contains("karo") || lower.contains("tap") || lower.contains("daba") || lower.contains("click")) {
                    val performed = screenPerceptionAgent.performActionOnFirstButton()
                    val feedback = if (performed) {
                        "${perception.summary}. Autonomous tap executed on primary interface element."
                    } else {
                        perception.summary
                    }
                    _assistantReply.value = feedback
                    speakResponse(feedback, query)
                } else {
                    speakResponse(perception.summary, query)
                }
                return@launch
            }

            // Step 4: Dynamic Search Grounding & Autonomous Research Brain
            if (researchBrain.isResearchCommand(query)) {
                val topic = researchBrain.extractTopic(query)
                researchBrain.setResearching(true)
                _assistantReply.value = "Conducting real-time grounded intelligence research on \"$topic\"..."

                val researchRes = repository.fetchResearch(topic)
                val briefing = researchBrain.processResearchResponse(topic, researchRes.briefing, researchRes.grounded)
                _assistantReply.value = briefing.fullBriefingText
                speakResponse(briefing.fullBriefingText, query)
                return@launch
            }

            // Step 5: Multi-Step Chained Action Execution
            if (chainedActionPlanner.isCompoundCommand(query)) {
                val steps = chainedActionPlanner.parseCompoundCommand(query)
                if (steps.size > 1) {
                    val firstAck = "Decomposing command into ${steps.size} sequential actions. Executing autonomously."
                    _assistantReply.value = firstAck
                    speakResponse(firstAck, query)

                    chainedActionPlanner.executeChain(
                        steps = steps,
                        onProgress = { progress ->
                            _assistantReply.value = progress
                        },
                        onComplete = { completion ->
                            _assistantReply.value = completion
                            speakResponse(completion, "completed")
                        }
                    )
                    return@launch
                }
            }

            // Step 6: Personal Memory & Recall Engine (Room Database)
            if (memoryRepository.isStoreMemoryCommand(query)) {
                val (key, content) = memoryRepository.parseMemoryInput(query)
                memoryRepository.saveMemory(key, content)
                val reply = "Saved to local memory database: \"$content\""
                _assistantReply.value = reply
                speakResponse(reply, query)
                return@launch
            }
            if (memoryRepository.isRecallMemoryCommand(query)) {
                val recalled = memoryRepository.queryMemory(query)
                val reply = if (recalled != null) {
                    "Recalled from memory: $recalled"
                } else {
                    "I checked my local memory storage, but could not find a record matching that query."
                }
                _assistantReply.value = reply
                speakResponse(reply, query)
                return@launch
            }

            // Step 7: Gaming & Performance Mode & Screen Recording Triggers
            if (gamingModeManager.isGamingCommand(query)) {
                val reply = gamingModeManager.setGamingMode(true)
                _assistantReply.value = reply
                speakResponse(reply, query)
                return@launch
            }
            if (gamingModeManager.isScreenRecordCommand(query)) {
                val reply = gamingModeManager.triggerScreenRecording()
                _assistantReply.value = reply
                speakResponse(reply, query)
                return@launch
            }

            // Step 8: Smart Battery & Charging Query
            if (batteryMonitor.isBatteryQuery(query)) {
                val report = batteryMonitor.getBatteryReport()
                _assistantReply.value = report
                speakResponse(report, query)
                return@launch
            }

            // Step 9: Scheduled Task Dispatcher (WorkManager)
            if (scheduledTaskDispatcher.isScheduleCommand(query)) {
                val (minutes, taskMsg) = scheduledTaskDispatcher.parseScheduleCommand(query)
                val ack = scheduledTaskDispatcher.scheduleReminder(minutes, taskMsg)
                _assistantReply.value = ack
                speakResponse(ack, query)
                return@launch
            }

            // Step 10: Dual-Core Brain Routing (Tier 1 On-Device <10ms vs Tier 2 Cloud Gemini)
            val brainResult = dualCoreBrainRouter.process(query)
            _assistantReply.value = brainResult.reply

            // Execute Action Intent if returned
            val intent = brainResult.actionIntent
            if (intent != null) {
                executeActionIntent(intent)
            }

            // Speak response with acoustic volume and emotional cadence modulation
            speakResponse(brainResult.reply, query)
        }
    }

    private fun executeActionIntent(intent: com.example.network.ActionIntent) {
        when (intent.type) {
            "MEDIA_YOUTUBE" -> {
                mediaBrain.launchYouTube(intent.query ?: "trending")
            }
            "MEDIA_YT_MUSIC" -> {
                mediaBrain.launchYouTubeMusic(intent.query ?: "top hits")
            }
            "SEND_WHATSAPP" -> {
                mediaBrain.launchWhatsApp(intent.query ?: "")
            }
            "TORCH" -> {
                if (intent.state != null) {
                    deviceController.setTorch(intent.state)
                } else {
                    deviceController.toggleTorch()
                }
            }
            "VOLUME" -> {
                if (intent.direction == "UP") {
                    deviceController.raiseVolume()
                } else {
                    deviceController.lowerVolume()
                }
            }
            "LOCK_SCREEN" -> {
                val locked = deviceController.lockScreen()
                if (!locked) {
                    Log.w(TAG, "Screen lock requires Orion Accessibility Service to be enabled.")
                }
            }
            "NAV_HOME" -> deviceController.goHome()
            "NAV_BACK" -> deviceController.goBack()
            "NOTIFICATIONS" -> deviceController.openNotifications()
            "WIFI_PANEL" -> deviceController.openWifiPanel()
            "BLUETOOTH_PANEL" -> deviceController.openBluetoothPanel()
        }
    }

    fun dismissPerceptionCard() {
        _activePerceptionCard.value = null
    }

    fun dismissResearchCard() {
        researchBrain.clearBriefing()
    }

    fun triggerScreenPerception() {
        processCommand("Orion, screen dekho aur batao")
    }

    fun toggleNotificationScreener(enabled: Boolean) {
        _notificationScreenerEnabled.value = enabled
    }

    fun sendNotificationAutoReply(key: String, reply: String): Boolean {
        return OrionNotificationListenerService.instance?.sendAutoReply(key, reply) ?: false
    }

    private fun speakResponse(text: String, originQuery: String = "") {
        _assistantState.value = AssistantState.SPEAKING
        if (!_isMuted.value) {
            // Acoustic Whisper & Dynamic Volume Adaptation
            val currentRms = speechEngine.soundLevel.value
            val acousticProfile = acousticWhisperAdapter.evaluateAcousticProfile(currentRms)

            // Emotional tone & speech cadence adaptation
            val emotionalState = emotionalToneAdapter.analyzeSpeechInput(originQuery.ifEmpty { text })
            val adaptedText = emotionalToneAdapter.adaptResponseText(text, emotionalState)
            ttsEngine.speakWithModulation(
                text = adaptedText,
                pacingMultiplier = emotionalState.pacingMultiplier * acousticProfile.pacingMultiplier,
                pitchMultiplier = emotionalState.pitchMultiplier * acousticProfile.pitchMultiplier,
                volumeMultiplier = acousticProfile.volumeMultiplier
            )
        }
        viewModelScope.launch {
            kotlinx.coroutines.delay(1200)
            _assistantState.value = AssistantState.IDLE
        }
    }

    /**
     * Handles detected air gesture and maps to global actions
     */
    fun onGestureTriggered(gesture: AirGestureDetector.GestureType) {
        val label = when (gesture) {
            AirGestureDetector.GestureType.SWIPE_UP -> {
                deviceController.scrollUp()
                "Swipe Up: Scrolled Up"
            }
            AirGestureDetector.GestureType.SWIPE_DOWN -> {
                deviceController.scrollDown()
                "Swipe Down: Scrolled Down"
            }
            AirGestureDetector.GestureType.SWIPE_RIGHT -> {
                deviceController.openRecents()
                "Swipe Right: Recents / Next Tab"
            }
            AirGestureDetector.GestureType.SWIPE_LEFT -> {
                deviceController.goBack()
                "Swipe Left: Global Back"
            }
            AirGestureDetector.GestureType.DOUBLE_FIST_HOME -> {
                deviceController.goHome()
                "Double Fist Clench: GLOBAL HOME"
            }
            AirGestureDetector.GestureType.PINCH_TAP -> {
                toggleMic()
                "Two-Finger Pinch: Mic Toggle"
            }
            AirGestureDetector.GestureType.NONE -> null
        }

        if (label != null) {
            _lastGestureEvent.value = label
            viewModelScope.launch {
                kotlinx.coroutines.delay(2500)
                if (_lastGestureEvent.value == label) {
                    _lastGestureEvent.value = null
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechEngine.destroy()
        ttsEngine.shutdown()
        airGestureDetector.stop()
        pocketGuardManager.stop()
        handsFreeReader.stop()
        batteryMonitor.stopListening()
        ambientContextEngine.stop()
        reactAgentEngine.cancel()
    }
}
