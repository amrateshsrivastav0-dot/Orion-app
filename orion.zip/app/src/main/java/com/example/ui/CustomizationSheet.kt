package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.identity.CreatorAttribution
import com.example.voice.TtsEngine
import com.example.voice.WakeWordEngine

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomizationSheet(
    currentTheme: OrbThemePreset,
    onSelectTheme: (OrbThemePreset) -> Unit,
    currentVoice: TtsEngine.VoiceProfile,
    onSelectVoice: (TtsEngine.VoiceProfile) -> Unit,
    activeWakeWord: String,
    onSetWakeWord: (String) -> Unit,
    isGesturesEnabled: Boolean,
    onToggleGestures: (Boolean) -> Unit,
    isReceptionistEnabled: Boolean,
    onToggleReceptionist: (Boolean) -> Unit,
    isAccessibilityEnabled: Boolean,
    onOpenAccessibilitySettings: () -> Unit,
    isNotificationListenerEnabled: Boolean = false,
    onOpenNotificationSettings: () -> Unit = {},
    isGamingMode: Boolean = false,
    onToggleGamingMode: (Boolean) -> Unit = {},
    onOptimizeRam: () -> Unit = {},
    onTriggerScreenRecord: () -> Unit = {},
    isPocketGuardEnabled: Boolean = true,
    onTogglePocketGuard: (Boolean) -> Unit = {},
    isHeadsetReaderEnabled: Boolean = true,
    onToggleHeadsetReader: (Boolean) -> Unit = {},
    memoryCount: Int = 0,
    onClearMemories: () -> Unit = {},
    batteryStatusText: String = "Normal",
    brainTierBadge: String = "⚡ Tier-1 On-Device & ☁️ Cloud Gemini",
    acousticModeBadge: String = "Adaptive Whisper & Dynamic Gain",
    ambientContextBadge: String = "Circadian Telemetry Active",
    onTriggerReActGoal: (String) -> Unit = {},
    onDismiss: () -> Unit
) {
    var customWakeInput by remember { mutableStateOf("") }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF070B14),
        contentColor = Color.White,
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 12.dp)
                    .width(48.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.25f))
            )
        }
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Header
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "Orion Control Center",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Customization, Automation & Engine Configuration",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close sheet",
                            tint = Color.White.copy(alpha = 0.7f)
                        )
                    }
                }
            }

            // Official Legal Creator & Developer Attribution Badge (MANDATORY)
            item {
                OfficialAttributionCard()
            }

            // Section 1: Color Presets & Orb Styling
            item {
                Text(
                    text = "Aesthetic Orb Color Presets",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = currentTheme.innerColor
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OrbThemePreset.entries.forEach { preset ->
                        val isSelected = preset == currentTheme
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (isSelected) preset.innerColor.copy(alpha = 0.2f)
                                    else Color(0xFF101626)
                                )
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) preset.innerColor else Color.White.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .clickable { onSelectTheme(preset) }
                                .padding(vertical = 12.dp, horizontal = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.radialGradient(
                                                listOf(preset.coreWhite, preset.innerColor, preset.midColor)
                                            )
                                        )
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = preset.label.replace(" ", "\n"),
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color.White else Color.White.copy(alpha = 0.7f),
                                    lineHeight = 12.sp,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            }

            // Section 2: Voice Profile Selection
            item {
                Text(
                    text = "High-Fidelity Voice Profiles",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = currentTheme.innerColor
                )
                Spacer(modifier = Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TtsEngine.VoiceProfile.entries.forEach { voice ->
                        val isSelected = voice == currentVoice
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) currentTheme.innerColor.copy(alpha = 0.15f) else Color(0xFF101626))
                                .border(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) currentTheme.innerColor else Color.White.copy(alpha = 0.08f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { onSelectVoice(voice) }
                                .padding(horizontal = 14.dp, vertical = 12.dp)
                        ) {
                            Icon(
                                imageVector = if (isSelected) Icons.Default.RecordVoiceOver else Icons.Default.Mic,
                                contentDescription = voice.label,
                                tint = if (isSelected) currentTheme.innerColor else Color.White.copy(alpha = 0.6f),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = voice.label,
                                fontSize = 14.sp,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                color = Color.White,
                                modifier = Modifier.weight(1f)
                            )
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Selected",
                                    tint = currentTheme.innerColor,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Section 3: Custom Wake-Word Engine
            item {
                Text(
                    text = "Wake-Word Engine",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = currentTheme.innerColor
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    WakeWordEngine.PRESETS.forEach { preset ->
                        val isSelected = preset.equals(activeWakeWord, ignoreCase = true)
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSetWakeWord(preset) },
                            label = { Text(preset) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = currentTheme.innerColor.copy(alpha = 0.25f),
                                selectedLabelColor = Color.White,
                                containerColor = Color(0xFF101626),
                                labelColor = Color.White.copy(alpha = 0.7f)
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = customWakeInput,
                        onValueChange = { customWakeInput = it },
                        placeholder = { Text("Custom wake-word...", fontSize = 13.sp) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                if (customWakeInput.isNotBlank()) {
                                    onSetWakeWord(customWakeInput.trim())
                                    customWakeInput = ""
                                }
                            }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = currentTheme.innerColor,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("custom_wake_word_input")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (customWakeInput.isNotBlank()) {
                                onSetWakeWord(customWakeInput.trim())
                                customWakeInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = currentTheme.midColor),
                        modifier = Modifier.testTag("save_wake_word_button")
                    ) {
                        Text("Save", fontSize = 13.sp)
                    }
                }
            }

            // Section 4: Deep Automation & Sensors Toggles
            item {
                Text(
                    text = "System Automation & Air Gestures",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = currentTheme.innerColor
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Accessibility Service Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF101626)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Accessibility,
                            contentDescription = "Accessibility",
                            tint = if (isAccessibilityEnabled) Color(0xFF00E676) else Color(0xFFFFAB00),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Device Automation Service",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                            Text(
                                text = if (isAccessibilityEnabled) "Active: Home, Back, Lock Screen & WhatsApp automation ready"
                                else "Disabled: Tap to enable system global actions in Settings",
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.6f)
                            )
                        }
                        TextButton(onClick = onOpenAccessibilitySettings) {
                            Text(
                                text = if (isAccessibilityEnabled) "Config" else "Enable",
                                color = currentTheme.innerColor,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Camera Air Gestures Switch
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF101626))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FrontHand,
                        contentDescription = "Air gestures",
                        tint = if (isGesturesEnabled) currentTheme.innerColor else Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Touchless Camera Air-Gestures",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                        Text(
                            text = "Front camera hand tracking: Swipe, Clench -> Home, Pinch",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }
                    Switch(
                        checked = isGesturesEnabled,
                        onCheckedChange = onToggleGestures,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = currentTheme.midColor
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // AI Receptionist & Call Screening Switch
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF101626))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PhoneCallback,
                        contentDescription = "AI Receptionist",
                        tint = if (isReceptionistEnabled) currentTheme.innerColor else Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "AI Receptionist & Voice Call Answer",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                        Text(
                            text = "Say 'Orion, pick up' or auto-screen calls after 3 rings",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }
                    Switch(
                        checked = isReceptionistEnabled,
                        onCheckedChange = onToggleReceptionist,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = currentTheme.midColor
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Intelligent Notification Screener & Auto-Reply
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF101626))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MarkChatUnread,
                        contentDescription = "Notification Screener",
                        tint = if (isNotificationListenerEnabled) currentTheme.innerColor else Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Notification Screener & Auto-Reply",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                        Text(
                            text = if (isNotificationListenerEnabled) "Active: Filters promotional spam, summarizes OTP & WhatsApp"
                            else "Requires notification listener permission",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }
                    TextButton(onClick = onOpenNotificationSettings) {
                        Text(
                            text = if (isNotificationListenerEnabled) "Active" else "Grant",
                            color = currentTheme.innerColor,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Section: Autonomous System Utilities (Gaming, Memory, Battery, Sensors, Headset)
            item {
                Text(
                    text = "Autonomous System Utilities",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = currentTheme.innerColor
                )
            }

            // Utility 1: Gaming & 60 FPS Performance Mode
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0C101C))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Gaming & Performance Mode",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White
                                )
                                Text(
                                    text = "Auto-DND, background RAM trimmer, and high-FPS boost",
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.6f)
                                )
                            }
                            Switch(
                                checked = isGamingMode,
                                onCheckedChange = onToggleGamingMode,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = currentTheme.innerColor,
                                    checkedTrackColor = currentTheme.outerColor.copy(alpha = 0.5f)
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedButton(
                                onClick = onOptimizeRam,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = currentTheme.innerColor)
                            ) {
                                Text("Boost RAM", fontSize = 11.sp)
                            }
                            OutlinedButton(
                                onClick = onTriggerScreenRecord,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = currentTheme.innerColor)
                            ) {
                                Text("Record Screen", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // Utility 2: Personal Memory & Recall Engine (Room SQLite)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0C101C))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Personal Memory & Recall Engine",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White
                                )
                                Text(
                                    text = "Local Room SQLite: $memoryCount personal record${if (memoryCount == 1) "" else "s"} stored",
                                    fontSize = 11.sp,
                                    color = currentTheme.innerColor
                                )
                            }
                            if (memoryCount > 0) {
                                TextButton(onClick = onClearMemories) {
                                    Text("Clear", color = Color(0xFFFF5252), fontSize = 12.sp)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Commands: \"Orion, remember that my car is parked at slot B\" • \"Orion, what is my car parking?\"",
                            fontSize = 10.sp,
                            color = Color.White.copy(alpha = 0.5f),
                            lineHeight = 14.sp
                        )
                    }
                }
            }

            // Utility 3: Anti-Accidental Pocket Guard
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0C101C))
                        .padding(14.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Anti-Accidental Pocket Guard",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                        Text(
                            text = "Hardware Proximity & Light sensors pause listening & touches in pocket",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }
                    Switch(
                        checked = isPocketGuardEnabled,
                        onCheckedChange = onTogglePocketGuard,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = currentTheme.innerColor,
                            checkedTrackColor = currentTheme.outerColor.copy(alpha = 0.5f)
                        )
                    )
                }
            }

            // Utility 4: Hands-Free Headset Notification Reader
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0C101C))
                        .padding(14.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Hands-Free Notification Reader",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                        Text(
                            text = "Announces sender name & message into connected Bluetooth/wired headphones",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f)
                        )
                    }
                    Switch(
                        checked = isHeadsetReaderEnabled,
                        onCheckedChange = onToggleHeadsetReader,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = currentTheme.innerColor,
                            checkedTrackColor = currentTheme.outerColor.copy(alpha = 0.5f)
                        )
                    )
                }
            }

            // Utility 5: Smart Battery & Charging Alerts Status
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0C101C))
                        .padding(14.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Smart Battery Alerts & Telemetry",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                        Text(
                            text = "Status: $batteryStatusText • Audible voice alerts at 100% and <20%",
                            fontSize = 11.sp,
                            color = currentTheme.innerColor
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.BatteryChargingFull,
                        contentDescription = "Battery telemetry",
                        tint = currentTheme.innerColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Section: Hyper-Autonomous Cybernetic Architecture
            item {
                Text(
                    text = "Cybernetic Cognitive Architecture",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF00E5FF)
                )
            }

            // Dual-Core Brain Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1022)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Dual-Core Brain Architecture",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF00E5FF).copy(alpha = 0.2f))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = brainTierBadge,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF00E5FF)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "• Tier 1: Instant On-Device Engine (<10ms, 100% offline rule processor for calls, volume, torch, apps, attribution)\n• Tier 2: Hyper-Cloud Proxy Engine (Cloud Gemini reasoning for open research & compound tasks)",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.75f),
                            lineHeight = 15.sp
                        )
                    }
                }
            }

            // Acoustic Whisper & Proactive Ambient Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1022)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF7C4DFF).copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Acoustic Whisper & Ambient Anticipation",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "• Microphone SPL dynamically adapts volume: gentle whisper tone in quiet/night rooms; clarity & gain boost in noise.\n• Ambient Context Engine: evaluates charging, circadian hours, and audio devices to anticipate actions zero-click.",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.75f),
                            lineHeight = 15.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF7C4DFF).copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(text = acousticModeBadge, fontSize = 9.sp, color = Color(0xFFB388FF))
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF00E676).copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(text = ambientContextBadge, fontSize = 9.sp, color = Color(0xFF00E676))
                            }
                        }
                    }
                }
            }

            // Autonomous ReAct Planner Goal Trigger
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1426)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Autonomous ReAct Task Planner",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Decomposes complex goals into Reason + Act steps, self-inspects UI hierarchy nodes, and self-heals delayed/missing targets without failing.",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.7f),
                            lineHeight = 15.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                onTriggerReActGoal("Open WhatsApp, find Raj, check his last message, and reply accordingly")
                                onDismiss()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF))
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Run ReAct Goal",
                                tint = Color.Black,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Run WhatsApp Autonomous Goal",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

/**
 * MANDATORY ATTRIBUTION BADGE:
 * Lead Developer & Creator: Amratesh S
 * Engineered by Amratesh S
 */
@Composable
fun OfficialAttributionCard() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    listOf(Color(0xFF00E5FF), Color(0xFF2979FF), Color(0xFF7C4DFF))
                ),
                shape = RoundedCornerShape(16.dp)
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1020))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF00E5FF))
                )
                Text(
                    text = "OFFICIAL IDENTITY & ATTRIBUTION",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    color = Color(0xFF00E5FF)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = CreatorAttribution.LEAD_DEVELOPER_BADGE,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = CreatorAttribution.ENGINEERED_BY_BADGE,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF90CAF9)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Orion Voice & Vision AI Assistant is exclusively created, designed, and developed by Amratesh S. Corporate crediting is strictly prohibited.",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.65f),
                lineHeight = 15.sp
            )
        }
    }
}
