package com.example.ui

import androidx.compose.ui.graphics.Color

/**
 * Color Presets for Orion Glowing Canvas Orb & Interface
 */
enum class OrbThemePreset(
    val label: String,
    val coreWhite: Color,
    val innerColor: Color,
    val midColor: Color,
    val outerColor: Color,
    val glowColor: Color
) {
    CYBER_OBSIDIAN(
        label = "Cyber Obsidian",
        coreWhite = Color(0xFFFFFFFF),
        innerColor = Color(0xFF00E5FF),
        midColor = Color(0xFF2979FF),
        outerColor = Color(0xFF030D26),
        glowColor = Color(0x6600E5FF)
    ),
    NEON_MATRIX(
        label = "Neon Matrix",
        coreWhite = Color(0xFFFFFFFF),
        innerColor = Color(0xFF00E676),
        midColor = Color(0xFF00C853),
        outerColor = Color(0xFF01210C),
        glowColor = Color(0x6600E676)
    ),
    CRIMSON_JARVIS(
        label = "Crimson Jarvis",
        coreWhite = Color(0xFFFFFFFF),
        innerColor = Color(0xFFFF9100),
        midColor = Color(0xFFD50000),
        outerColor = Color(0xFF2B0202),
        glowColor = Color(0x66FF1744)
    ),
    AURA_PURPLE(
        label = "Aura Purple",
        coreWhite = Color(0xFFFFFFFF),
        innerColor = Color(0xFFE040FB),
        midColor = Color(0xFF7C4DFF),
        outerColor = Color(0xFF1B032D),
        glowColor = Color(0x66E040FB)
    )
}
