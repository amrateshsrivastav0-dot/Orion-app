package com.example.ui

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.example.ambient.AmbientContextEngine
import com.example.automation.ChainedActionPlanner
import com.example.automation.OrionAccessibilityService
import com.example.automation.ReActAgentEngine
import com.example.brain.DualCoreBrainRouter
import com.example.notifications.OrionNotificationListenerService
import com.example.research.AutonomousResearchBrain
import com.example.telecom.SmartCallManager
import com.example.vision.ScreenPerceptionAgent
import com.example.voice.AcousticWhisperAdapter
import com.example.voice.EmotionalToneAdapter
import kotlinx.coroutines.launch

@Composable
fun OrionScreen(
    viewModel: OrionViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val assistantState by viewModel.assistantState.collectAsStateWithLifecycle()
    val currentTheme by viewModel.currentTheme.collectAsStateWithLifecycle()
    val isListening by viewModel.speechEngine.isListening.collectAsStateWithLifecycle()
    val soundLevel by viewModel.speechEngine.soundLevel.collectAsStateWithLifecycle()
    val userTranscript by viewModel.userTranscript.collectAsStateWithLifecycle()
    val assistantReply by viewModel.assistantReply.collectAsStateWithLifecycle()
    val isMuted by viewModel.isMuted.collectAsStateWithLifecycle()
    val showCustomization by viewModel.showCustomizationSheet.collectAsStateWithLifecycle()
    val isGesturesEnabled by viewModel.isGesturesEnabled.collectAsStateWithLifecycle()
    val lastGestureEvent by viewModel.lastGestureEvent.collectAsStateWithLifecycle()
    val activeWakeWord by viewModel.wakeWordEngine.activeWakeWord.collectAsStateWithLifecycle()
    val currentVoice by viewModel.ttsEngine.currentProfile.collectAsStateWithLifecycle()
    val receptionistEnabled by viewModel.callManager.receptionistEnabled.collectAsStateWithLifecycle()
    val callState by viewModel.callManager.callState.collectAsStateWithLifecycle()
    val incomingNumber by viewModel.callManager.incomingNumber.collectAsStateWithLifecycle()

    // Autonomous Cognitive Agents State
    val chainedState by viewModel.chainedActionPlanner.executionState.collectAsStateWithLifecycle()
    val activePerception by viewModel.activePerceptionCard.collectAsStateWithLifecycle()
    val currentBriefing by viewModel.researchBrain.currentBriefing.collectAsStateWithLifecycle()
    val emotionalUrgency by viewModel.emotionalToneAdapter.currentUrgency.collectAsStateWithLifecycle()
    val urgentNotification by OrionNotificationListenerService.latestUrgentNotification.collectAsStateWithLifecycle()

    // Autonomous Utility Suite States (Sensors, Gaming, Battery, Headset, Memory)
    val isInPocket by viewModel.pocketGuardManager.isInPocket.collectAsStateWithLifecycle()
    val isPocketGuardEnabled by viewModel.pocketGuardManager.isGuardEnabled.collectAsStateWithLifecycle()
    val isGamingMode by viewModel.gamingModeManager.isGamingModeActive.collectAsStateWithLifecycle()
    val batteryState by viewModel.batteryMonitor.batteryState.collectAsStateWithLifecycle()
    val isHeadsetConnected by viewModel.handsFreeReader.isHeadsetConnected.collectAsStateWithLifecycle()
    val isHeadsetReaderEnabled by viewModel.handsFreeReader.isEnabled.collectAsStateWithLifecycle()
    val memoriesList by viewModel.memoryRepository.allMemories.collectAsStateWithLifecycle(initialValue = emptyList())

    // Autonomous Self-Healing ReAct & Dual-Core Brain & Ambient States
    val reactState by viewModel.reactAgentEngine.executionState.collectAsStateWithLifecycle()
    val brainTier by viewModel.dualCoreBrainRouter.lastUsedTier.collectAsStateWithLifecycle()
    val brainLatency by viewModel.dualCoreBrainRouter.lastLatency.collectAsStateWithLifecycle()
    val acousticMode by viewModel.acousticWhisperAdapter.currentMode.collectAsStateWithLifecycle()
    val ambientSnapshot by viewModel.ambientContextEngine.snapshot.collectAsStateWithLifecycle()
    val ambientAnticipation by viewModel.ambientContextEngine.latestAnticipation.collectAsStateWithLifecycle()

    var isAccessibilityEnabled by remember {
        mutableStateOf(OrionAccessibilityService.isServiceEnabled(context))
    }
    var isNotificationAccessGranted by remember {
        mutableStateOf(OrionNotificationListenerService.isNotificationAccessGranted(context))
    }

    // Permission request launchers
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val micGranted = permissions[Manifest.permission.RECORD_AUDIO] == true
        val cameraGranted = permissions[Manifest.permission.CAMERA] == true
        if (cameraGranted && isGesturesEnabled) {
            viewModel.airGestureDetector.start(lifecycleOwner) { gesture ->
                viewModel.onGestureTriggered(gesture)
            }
        }
    }

    LaunchedEffect(Unit) {
        val permissionsToRequest = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.CAMERA)
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }
        if (permissionsToRequest.isNotEmpty()) {
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        } else if (isGesturesEnabled) {
            viewModel.airGestureDetector.start(lifecycleOwner) { gesture ->
                viewModel.onGestureTriggered(gesture)
            }
        }
    }

    // AMOLED True Pitch-Black Canvas Box
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Status Bar (HUD Header with Emotional Cadence Indicator)
            TopHudHeader(
                activeWakeWord = activeWakeWord,
                theme = currentTheme,
                emotionalUrgency = emotionalUrgency,
                brainTier = brainTier,
                acousticMode = acousticMode,
                isGesturesEnabled = isGesturesEnabled,
                isAccessibilityEnabled = isAccessibilityEnabled,
                batteryLevel = batteryState.level,
                isBatteryCharging = batteryState.isCharging,
                isHeadsetConnected = isHeadsetConnected,
                isGamingMode = isGamingMode,
                onOpenAbout = {
                    isAccessibilityEnabled = OrionAccessibilityService.isServiceEnabled(context)
                    isNotificationAccessGranted = OrionNotificationListenerService.isNotificationAccessGranted(context)
                    viewModel.toggleCustomizationSheet(true)
                }
            )

            // Autonomous Self-Healing ReAct Agent Loop Banner
            AnimatedVisibility(
                visible = reactState.isExecuting || (reactState.stepIndex > 0 && reactState.historyLogs.isNotEmpty()),
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                ReActAgentLoopCard(
                    state = reactState,
                    theme = currentTheme,
                    onCancel = { viewModel.reactAgentEngine.cancel() }
                )
            }

            // Proactive Ambient Anticipated Action Banner
            AnimatedVisibility(
                visible = ambientAnticipation != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                ambientAnticipation?.let { action ->
                    AmbientAnticipationCard(
                        action = action,
                        theme = currentTheme,
                        onDismiss = { viewModel.ambientContextEngine.dismissAnticipation() }
                    )
                }
            }

            // Anti-Accidental Pocket Guard Banner
            AnimatedVisibility(
                visible = isInPocket,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                PocketGuardAlertCard(theme = currentTheme)
            }

            // Gaming & Performance Mode Active Banner
            AnimatedVisibility(
                visible = isGamingMode,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                GamingModeHudCard(
                    theme = currentTheme,
                    onBoostRam = { viewModel.processCommand("Boost RAM") },
                    onRecordScreen = { viewModel.processCommand("Record screen") }
                )
            }

            // Autonomous Chained Action Execution Progress Banner
            AnimatedVisibility(
                visible = chainedState.isExecuting,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                ChainedExecutionCard(
                    state = chainedState,
                    theme = currentTheme,
                    onCancel = { viewModel.chainedActionPlanner.cancelChain() }
                )
            }

            // Incoming Call Alert Banner (Smart Call Screening)
            if (callState == SmartCallManager.CallState.RINGING) {
                IncomingCallBanner(
                    caller = incomingNumber ?: "Incoming Call",
                    theme = currentTheme,
                    onAnswer = {
                        viewModel.callManager.answerCallWithSpeaker { msg ->
                            viewModel.processCommand(msg)
                        }
                    }
                )
            }

            // Urgent Notification Screener Banner
            urgentNotification?.let { notif ->
                UrgentNotificationCard(
                    notification = notif,
                    theme = currentTheme,
                    onVoiceSummarize = {
                        viewModel.processCommand("Summarize notification from ${notif.appName}: ${notif.title} ${notif.text}")
                    },
                    onAutoReply = { reply ->
                        viewModel.sendNotificationAutoReply(notif.key, reply)
                    }
                )
            }

            // Air Gesture Live HUD Notification
            AnimatedVisibility(
                visible = lastGestureEvent != null,
                enter = fadeIn() + slideInVertically(),
                exit = fadeOut() + slideOutVertically()
            ) {
                lastGestureEvent?.let { gestureText ->
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 24.dp, vertical = 4.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xCC002B36))
                            .border(1.dp, currentTheme.innerColor, RoundedCornerShape(16.dp))
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.FrontHand,
                                contentDescription = "Gesture",
                                tint = currentTheme.innerColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = gestureText,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // On-Demand Screen Perception Card
            activePerception?.let { perception ->
                ScreenPerceptionCard(
                    result = perception,
                    theme = currentTheme,
                    onAction = {
                        viewModel.screenPerceptionAgent.performActionOnFirstButton()
                    },
                    onDismiss = { viewModel.dismissPerceptionCard() }
                )
            }

            // Autonomous Research Intelligence Briefing Card (Google Search Grounding)
            currentBriefing?.let { briefing ->
                ResearchBriefingCard(
                    briefing = briefing,
                    theme = currentTheme,
                    onDismiss = { viewModel.dismissResearchCard() }
                )
            }

            // Center Dynamic Glowing Orb (100% Native Jetpack Compose Canvas)
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    OrionOrb(
                        state = assistantState,
                        theme = currentTheme,
                        audioLevel = soundLevel,
                        modifier = Modifier
                            .clickable { viewModel.toggleMic() }
                            .testTag("orion_canvas_orb")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Spoken transcript & status HUD
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp)
                    ) {
                        if (userTranscript.isNotBlank()) {
                            Text(
                                text = "\"$userTranscript\"",
                                fontSize = 13.sp,
                                color = Color.White.copy(alpha = 0.65f),
                                textAlign = TextAlign.Center,
                                maxLines = 2,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }

                        Text(
                            text = assistantReply,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            lineHeight = 22.sp
                        )
                    }
                }
            }

            // Floating Controls Glassmorphic Dock
            FloatingControlsDock(
                isListening = isListening,
                isMuted = isMuted,
                theme = currentTheme,
                onMicClick = { viewModel.toggleMic() },
                onMuteToggle = { viewModel.toggleMute() },
                onSendText = { query -> viewModel.submitTextQuery(query) },
                onOpenSettings = {
                    isAccessibilityEnabled = OrionAccessibilityService.isServiceEnabled(context)
                    isNotificationAccessGranted = OrionNotificationListenerService.isNotificationAccessGranted(context)
                    viewModel.toggleCustomizationSheet(true)
                },
                onExitClick = {
                    (context as? Activity)?.finish()
                }
            )
        }

        // In-App Customization & About Sheet
        if (showCustomization) {
            CustomizationSheet(
                currentTheme = currentTheme,
                onSelectTheme = { viewModel.setTheme(it) },
                currentVoice = currentVoice,
                onSelectVoice = { viewModel.setVoiceProfile(it) },
                activeWakeWord = activeWakeWord,
                onSetWakeWord = { viewModel.setWakeWord(it) },
                isGesturesEnabled = isGesturesEnabled,
                onToggleGestures = { viewModel.toggleAirGestures(it) },
                isReceptionistEnabled = receptionistEnabled,
                onToggleReceptionist = { viewModel.callManager.setReceptionistEnabled(it) },
                isAccessibilityEnabled = isAccessibilityEnabled,
                onOpenAccessibilitySettings = { OrionAccessibilityService.openAccessibilitySettings(context) },
                isNotificationListenerEnabled = isNotificationAccessGranted,
                onOpenNotificationSettings = { OrionNotificationListenerService.openNotificationAccessSettings(context) },
                isGamingMode = isGamingMode,
                onToggleGamingMode = { viewModel.gamingModeManager.setGamingMode(it) },
                onOptimizeRam = { viewModel.processCommand("Optimize RAM") },
                onTriggerScreenRecord = { viewModel.processCommand("Record screen") },
                isPocketGuardEnabled = isPocketGuardEnabled,
                onTogglePocketGuard = { viewModel.pocketGuardManager.toggleGuard(it) },
                isHeadsetReaderEnabled = isHeadsetReaderEnabled,
                onToggleHeadsetReader = { viewModel.handsFreeReader.toggleEnabled(it) },
                memoryCount = memoriesList.size,
                onClearMemories = {
                    viewModel.viewModelScope.launch { viewModel.memoryRepository.clearAll() }
                },
                batteryStatusText = "${batteryState.level}% ${if (batteryState.isCharging) "(Charging)" else ""}, ${batteryState.temperatureCelsius}°C",
                brainTierBadge = brainTier.badge,
                acousticModeBadge = acousticMode.badge,
                ambientContextBadge = "${ambientSnapshot.timeOfDayTag}${if (!ambientSnapshot.locationTag.isNullOrBlank()) " • " + ambientSnapshot.locationTag else ""} • ${ambientSnapshot.activeProfileTag}",
                onTriggerReActGoal = { goal -> viewModel.processCommand(goal) },
                onDismiss = { viewModel.toggleCustomizationSheet(false) }
            )
        }
    }
}

@Composable
private fun TopHudHeader(
    activeWakeWord: String,
    theme: OrbThemePreset,
    emotionalUrgency: EmotionalToneAdapter.EmotionalUrgency,
    brainTier: DualCoreBrainRouter.BrainTier = DualCoreBrainRouter.BrainTier.TIER_1_ON_DEVICE,
    acousticMode: AcousticWhisperAdapter.AcousticMode = AcousticWhisperAdapter.AcousticMode.NORMAL,
    isGesturesEnabled: Boolean,
    isAccessibilityEnabled: Boolean,
    batteryLevel: Int = 100,
    isBatteryCharging: Boolean = false,
    isHeadsetConnected: Boolean = false,
    isGamingMode: Boolean = false,
    onOpenAbout: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Assistant Brand Badge
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF0C101C))
                .border(1.dp, theme.innerColor.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
                .clickable { onOpenAbout() }
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(theme.innerColor)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "ORION AI",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = Color.White
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "• $activeWakeWord",
                fontSize = 11.sp,
                color = theme.innerColor
            )
        }

        // Indicators: Brain Tier, Whisper, Cadence & Battery & Settings
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Dual-Core Brain Tier Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0C101C))
                    .border(
                        0.5.dp,
                        if (brainTier == DualCoreBrainRouter.BrainTier.TIER_1_ON_DEVICE) Color(0xFF00E5FF).copy(alpha = 0.5f)
                        else Color(0xFFB388FF).copy(alpha = 0.5f),
                        RoundedCornerShape(12.dp)
                    )
                    .padding(horizontal = 6.dp, vertical = 4.dp)
            ) {
                Text(
                    text = if (brainTier == DualCoreBrainRouter.BrainTier.TIER_1_ON_DEVICE) "⚡ T1" else "☁️ T2",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (brainTier == DualCoreBrainRouter.BrainTier.TIER_1_ON_DEVICE) Color(0xFF00E5FF) else Color(0xFFB388FF)
                )
            }

            // Acoustic Whisper Mode Badge
            if (acousticMode == AcousticWhisperAdapter.AcousticMode.WHISPER) {
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFF0C101C))
                        .padding(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Bedtime,
                        contentDescription = "Whisper Mode",
                        tint = Color(0xFFB388FF),
                        modifier = Modifier.size(13.dp)
                    )
                }
            }

            // Emotional Cadence Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0C101C))
                    .border(0.5.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = emotionalUrgency.label,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = theme.innerColor
                )
            }

            // Headset Indicator
            if (isHeadsetConnected) {
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFF0C101C))
                        .padding(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Headphones,
                        contentDescription = "Headset connected",
                        tint = theme.innerColor,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }

            // Battery Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0C101C))
                    .border(0.5.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 7.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "$batteryLevel%${if (isBatteryCharging) "⚡" else ""}",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (batteryLevel <= 20) Color(0xFFFF5252) else Color.White.copy(alpha = 0.85f)
                )
            }

            if (isGesturesEnabled) {
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFF0C101C))
                        .padding(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FrontHand,
                        contentDescription = "Air gestures active",
                        tint = theme.innerColor,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0xFF0C101C))
                    .clickable { onOpenAbout() }
                    .padding(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = Color.White.copy(alpha = 0.7f),
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}

@Composable
private fun ReActAgentLoopCard(
    state: ReActAgentEngine.ReActExecutionState,
    theme: OrbThemePreset,
    onCancel: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .border(1.dp, Color(0xFF00E5FF).copy(alpha = 0.6f), RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xF0061220)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (state.isExecuting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = Color(0xFF00E5FF)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Completed",
                            tint = Color(0xFF00E676),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ReAct Autonomous Loop",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00E5FF)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "(${state.stepIndex}/${state.totalSteps})",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (!state.healingStatus.isNullOrBlank()) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF00E676).copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = state.healingStatus ?: "",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00E676)
                            )
                        }
                    }
                    if (state.isExecuting) {
                        IconButton(onClick = onCancel, modifier = Modifier.size(24.dp)) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Cancel ReAct loop",
                                tint = Color.White.copy(alpha = 0.6f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            if (state.goal.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Goal: ${state.goal}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )
            }

            if (state.thought.isNotBlank()) {
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "Thought: ${state.thought}",
                    fontSize = 11.sp,
                    color = Color(0xFFB388FF),
                    lineHeight = 14.sp
                )
            }

            if (state.currentAction.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Action: ${state.currentAction}",
                    fontSize = 11.sp,
                    color = Color(0xFF80D8FF),
                    lineHeight = 14.sp
                )
            }

            if (state.observation.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Observation: ${state.observation}",
                    fontSize = 10.sp,
                    color = Color.White.copy(alpha = 0.65f),
                    lineHeight = 13.sp
                )
            }
        }
    }
}

@Composable
private fun AmbientAnticipationCard(
    action: AmbientContextEngine.AnticipationAction,
    theme: OrbThemePreset,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .border(1.dp, Color(0xFF00E676).copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xEE091B13)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF00E676).copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoMode,
                    contentDescription = "Anticipated Action",
                    tint = Color(0xFF00E676),
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = action.title,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    if (action.autoExecuted) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF00E676).copy(alpha = 0.3f))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text("AUTO-EXECUTED", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00E676))
                        }
                    }
                }
                Text(
                    text = action.description,
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.75f),
                    lineHeight = 14.sp
                )
            }
            IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Dismiss",
                    tint = Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun ChainedExecutionCard(
    state: ChainedActionPlanner.ExecutionState,
    theme: OrbThemePreset,
    onCancel: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .border(1.dp, theme.innerColor.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xDD0D1628)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(12.dp)
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                strokeWidth = 2.dp,
                color = theme.innerColor
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Chained Action: Step ${state.currentStepIndex} of ${state.totalSteps}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = state.statusMessage,
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.75f),
                    maxLines = 1
                )
            }
            IconButton(onClick = onCancel, modifier = Modifier.size(24.dp)) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Cancel chain",
                    tint = Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun ScreenPerceptionCard(
    result: ScreenPerceptionAgent.PerceptionResult,
    theme: OrbThemePreset,
    onAction: () -> Unit,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .border(1.dp, Color(0xFF00E5FF).copy(alpha = 0.6f), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xF0071322)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Visibility,
                        contentDescription = "Vision Agent",
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Vision Perception: ${result.appName}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                IconButton(onClick = onDismiss, modifier = Modifier.size(20.dp)) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Dismiss",
                        tint = Color.White.copy(alpha = 0.6f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = result.summary,
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.85f),
                lineHeight = 17.sp
            )
            if (result.suggestedAction != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onAction,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Auto-Execute: ${result.suggestedAction}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
            }
        }
    }
}

@Composable
private fun ResearchBriefingCard(
    briefing: AutonomousResearchBrain.ResearchBriefing,
    theme: OrbThemePreset,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .border(1.dp, Color(0xFF7C4DFF).copy(alpha = 0.6f), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xF00F0C24)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Search Grounding",
                        tint = Color(0xFFB388FF),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Research: ${briefing.topic}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "30s Audio Briefing",
                        fontSize = 10.sp,
                        color = Color(0xFFB388FF)
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(20.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Dismiss",
                            tint = Color.White.copy(alpha = 0.6f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = briefing.executiveSummary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            briefing.keyPoints.take(2).forEach { pt ->
                Text(
                    text = "• $pt",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.75f)
                )
            }
        }
    }
}

@Composable
private fun UrgentNotificationCard(
    notification: OrionNotificationListenerService.ScreenedNotification,
    theme: OrbThemePreset,
    onVoiceSummarize: () -> Unit,
    onAutoReply: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .border(1.dp, Color(0xFFFFB300), RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xEE1E1705)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(12.dp)
        ) {
            Icon(
                imageVector = Icons.Default.NotificationsActive,
                contentDescription = "Urgent alert",
                tint = Color(0xFFFFB300),
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${notification.appName}: ${notification.title}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = notification.text,
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.8f),
                    maxLines = 1
                )
            }
            if (notification.hasReplyAction) {
                TextButton(onClick = { onAutoReply("Understood. I will follow up shortly via Orion.") }) {
                    Text("Auto-Reply", fontSize = 11.sp, color = Color(0xFFFFB300), fontWeight = FontWeight.Bold)
                }
            } else {
                TextButton(onClick = onVoiceSummarize) {
                    Text("Read", fontSize = 11.sp, color = Color(0xFFFFB300))
                }
            }
        }
    }
}

@Composable
private fun IncomingCallBanner(
    caller: String,
    theme: OrbThemePreset,
    onAnswer: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .border(1.dp, Color(0xFF00E676), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF071B10)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(14.dp)
        ) {
            Icon(
                imageVector = Icons.Default.PhoneInTalk,
                contentDescription = "Incoming call",
                tint = Color(0xFF00E676),
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Incoming Call: $caller",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Say 'Orion, pick up' or tap to answer with speaker",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.7f)
                )
            }
            Button(
                onClick = onAnswer,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676))
            ) {
                Text("Answer", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun PocketGuardAlertCard(theme: OrbThemePreset) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 4.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF070B14)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF00E5FF).copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Pocket Guard Protected",
                    tint = Color(0xFF00E5FF),
                    modifier = Modifier.size(18.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "POCKET GUARD ACTIVE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = Color(0xFF00E5FF)
                )
                Text(
                    text = "Device enclosed in pocket. Wake-word & accidental touch inputs paused.",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.7f),
                    lineHeight = 14.sp
                )
            }
        }
    }
}

@Composable
fun GamingModeHudCard(
    theme: OrbThemePreset,
    onBoostRam: () -> Unit,
    onRecordScreen: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 4.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A0F1D)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFF9100).copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFF9100))
                )
                Text(
                    text = "PERFORMANCE MODE (60 FPS • DND)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp,
                    color = Color(0xFFFF9100)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(
                    onClick = onBoostRam,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = "Boost RAM",
                        tint = theme.innerColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
                IconButton(
                    onClick = onRecordScreen,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = "Record Screen",
                        tint = Color(0xFFFF5252),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
