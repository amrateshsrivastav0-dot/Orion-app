package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// AMOLED True Pitch-Black Theme for ORION
private val OrionDarkColorScheme = darkColorScheme(
    primary = Color(0xFF00E5FF),
    onPrimary = Color.Black,
    secondary = Color(0xFF2979FF),
    onSecondary = Color.White,
    tertiary = Color(0xFF7C4DFF),
    background = Color(0xFF000000),
    onBackground = Color.White,
    surface = Color(0xFF070B14),
    onSurface = Color.White,
    surfaceVariant = Color(0xFF101626),
    onSurfaceVariant = Color(0xFFB0BEC5)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to true pitch black for ORION
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = OrionDarkColorScheme,
        typography = Typography,
        content = content
    )
}
