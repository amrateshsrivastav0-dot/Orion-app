package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R

/**
 * Translucent Pill-Shaped Glassmorphism Controls Dock
 * Includes 'Ask Orion...' input, animated mic toggle, mute toggle, and action controls.
 */
@Composable
fun FloatingControlsDock(
    isListening: Boolean,
    isMuted: Boolean,
    theme: OrbThemePreset,
    onMicClick: () -> Unit,
    onMuteToggle: () -> Unit,
    onSendText: (String) -> Unit,
    onOpenSettings: () -> Unit,
    onExitClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var textInput by remember { mutableStateOf("") }
    var isInputExpanded by remember { mutableStateOf(false) }

    // Pulsing scale for active mic
    val infiniteTransition = rememberInfiniteTransition(label = "MicPulse")
    val micScale by if (isListening) {
        infiniteTransition.animateFloat(
            initialValue = 1.0f,
            targetValue = 1.18f,
            animationSpec = infiniteRepeatable(
                animation = tween(600, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "MicScalePulse"
        )
    } else {
        remember { mutableFloatStateOf(1.0f) }
    }

    val micGlowColor by animateColorAsState(
        targetValue = if (isListening) theme.innerColor else Color.White.copy(alpha = 0.2f),
        label = "MicGlow"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Expandable Text Input Bar for "Ask Orion..."
        AnimatedVisibility(visible = isInputExpanded) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xCC121624))
                    .border(1.dp, theme.innerColor.copy(alpha = 0.35f), RoundedCornerShape(24.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    BasicTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        textStyle = TextStyle(
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Normal
                        ),
                        cursorBrush = SolidColor(theme.innerColor),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (textInput.isNotBlank()) {
                                    onSendText(textInput)
                                    textInput = ""
                                    isInputExpanded = false
                                }
                            }
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ask_orion_input_field"),
                        decorationBox = { innerTextField ->
                            if (textInput.isEmpty()) {
                                Text(
                                    text = stringResource(R.string.ask_orion_hint),
                                    color = Color.White.copy(alpha = 0.45f),
                                    fontSize = 15.sp
                                )
                            }
                            innerTextField()
                        }
                    )

                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank()) {
                                onSendText(textInput)
                                textInput = ""
                                isInputExpanded = false
                            }
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("send_query_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send query",
                            tint = theme.innerColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // Main Glassmorphic Translucent Pill Dock
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(32.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xCC101524),
                            Color(0xEE090D18)
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    brush = Brush.horizontalGradient(
                        listOf(
                            theme.innerColor.copy(alpha = 0.3f),
                            Color.White.copy(alpha = 0.15f),
                            theme.innerColor.copy(alpha = 0.3f)
                        )
                    ),
                    shape = RoundedCornerShape(32.dp)
                )
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Keyboard / Input Toggle Button
                IconButton(
                    onClick = { isInputExpanded = !isInputExpanded },
                    modifier = Modifier
                        .size(44.dp)
                        .testTag("toggle_keyboard_button")
                ) {
                    Icon(
                        imageVector = if (isInputExpanded) Icons.Default.Close else Icons.Default.Keyboard,
                        contentDescription = "Toggle Keyboard Input",
                        tint = if (isInputExpanded) theme.innerColor else Color.White.copy(alpha = 0.75f),
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Mute / Speaker Toggle Button
                IconButton(
                    onClick = onMuteToggle,
                    modifier = Modifier
                        .size(44.dp)
                        .testTag("mute_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                        contentDescription = "Toggle Mute",
                        tint = if (isMuted) Color(0xFFFF5252) else Color.White.copy(alpha = 0.75f),
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Central Hero Animated Mic Toggle Button
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .scale(micScale)
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    micGlowColor.copy(alpha = 0.85f),
                                    theme.midColor.copy(alpha = 0.65f),
                                    Color(0xFF040A18)
                                )
                            )
                        )
                        .border(
                            width = if (isListening) 2.dp else 1.dp,
                            color = micGlowColor,
                            shape = CircleShape
                        )
                        .clickable { onMicClick() }
                        .testTag("animated_mic_button")
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicNone,
                        contentDescription = "Toggle Voice Listening",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }

                // Settings & Customization Sheet Button
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .size(44.dp)
                        .testTag("settings_sheet_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Customization and Settings",
                        tint = Color.White.copy(alpha = 0.75f),
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Exit / Close Button
                IconButton(
                    onClick = onExitClick,
                    modifier = Modifier
                        .size(44.dp)
                        .testTag("exit_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PowerSettingsNew,
                        contentDescription = "Exit Orion",
                        tint = Color(0xFFFF5252).copy(alpha = 0.85f),
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}
