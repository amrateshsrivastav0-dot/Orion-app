package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

enum class AssistantState {
    IDLE,
    LISTENING,
    PROCESSING,
    SPEAKING
}

/**
 * 100% Native Jetpack Compose Canvas Glowing Orb
 * Zero heavy media (No Lottie, No MP4, No GIF) for 60 FPS ultra-smoothness on low-end hardware.
 * Hypnotic breathing, expanding dynamic ripple rings, and real-time audio reactivity.
 */
@Composable
fun OrionOrb(
    state: AssistantState,
    theme: OrbThemePreset,
    audioLevel: Float, // 0.0f to 1.0f
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "OrionOrbMotion")

    // Breathing scale animation for Idle mode (sinusoidal pulse)
    val breathingScale by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "OrbBreathing"
    )

    // Ripple expansion progress for Active / Listening / Speaking mode
    val rippleProgress1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Ripple1"
    )

    val rippleProgress2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, delayMillis = 1100, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Ripple2"
    )

    // Rotation phase for processing/speaking energy nodes
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "OrbRotation"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .fillMaxWidth()
            .height(360.dp)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
        ) {
            val centerOffset = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = (size.minDimension / 4.2f)

            // Calculate dynamic scale modulated by state & audio level
            val stateScale = when (state) {
                AssistantState.IDLE -> breathingScale
                AssistantState.LISTENING -> 1.0f + (audioLevel * 0.35f)
                AssistantState.PROCESSING -> 0.95f + (breathingScale - 0.88f) * 0.5f
                AssistantState.SPEAKING -> 1.05f + (audioLevel * 0.45f) + (sin(Math.toRadians(rotationAngle * 3.0).toFloat()) * 0.06f)
            }
            val orbRadius = baseRadius * stateScale

            // Draw Dynamic Ripple Rings for Listening & Speaking states
            if (state == AssistantState.LISTENING || state == AssistantState.SPEAKING) {
                drawRippleRing(centerOffset, orbRadius, rippleProgress1, theme.glowColor)
                drawRippleRing(centerOffset, orbRadius, rippleProgress2, theme.glowColor)
            }

            // Outer Atmospheric Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        theme.glowColor,
                        theme.outerColor.copy(alpha = 0.4f),
                        Color.Transparent
                    ),
                    center = centerOffset,
                    radius = orbRadius * 1.8f
                ),
                radius = orbRadius * 1.8f,
                center = centerOffset
            )

            // Primary Glowing Orb Canvas with Radial Gradients
            drawCircle(
                brush = Brush.radialGradient(
                    colorStops = arrayOf(
                        0.0f to theme.coreWhite,
                        0.25f to theme.innerColor,
                        0.60f to theme.midColor,
                        0.88f to theme.outerColor,
                        1.0f to Color.Transparent
                    ),
                    center = centerOffset,
                    radius = orbRadius
                ),
                radius = orbRadius,
                center = centerOffset
            )

            // Waveform expansion & particle nodes for Active/Speaking state
            if (state == AssistantState.SPEAKING || state == AssistantState.PROCESSING) {
                val nodeCount = if (state == AssistantState.SPEAKING) 12 else 6
                val orbitRadius = orbRadius * 1.18f
                for (i in 0 until nodeCount) {
                    val angleDeg = rotationAngle + (i * (360f / nodeCount))
                    val rad = Math.toRadians(angleDeg.toDouble())
                    val nodeX = centerOffset.x + (orbitRadius * cos(rad)).toFloat()
                    val nodeY = centerOffset.y + (orbitRadius * sin(rad)).toFloat()
                    val nodeRadius = 3.5.dp.toPx() * (1f + audioLevel * 0.8f)

                    drawCircle(
                        color = theme.innerColor.copy(alpha = 0.85f),
                        radius = nodeRadius,
                        center = Offset(nodeX, nodeY)
                    )
                }

                // Inner electric harmonic ring
                drawCircle(
                    color = theme.innerColor.copy(alpha = 0.5f),
                    radius = orbRadius * 0.96f,
                    center = centerOffset,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawRippleRing(
    center: Offset,
    orbRadius: Float,
    progress: Float,
    color: Color
) {
    val ringRadius = orbRadius + (progress * orbRadius * 1.1f)
    val ringAlpha = (1f - progress).coerceIn(0f, 1f) * 0.7f
    drawCircle(
        color = color.copy(alpha = ringAlpha),
        radius = ringRadius,
        center = center,
        style = Stroke(width = (3.dp.toPx() * (1f - progress * 0.5f)).coerceAtLeast(1f))
    )
}
