package com.example.sensors

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Anti-Accidental Pocket Guard Engine
 * Uses hardware Proximity and Light sensors to detect when the phone is enclosed in a pocket or bag.
 * Prevents accidental screen touches and pauses wake-word background listening to save battery.
 */
class PocketGuardManager(
    private val context: Context,
    private val onPocketStateChanged: (isInPocket: Boolean) -> Unit
) : SensorEventListener {

    companion object {
        private const val TAG = "PocketGuardManager"
        private const val DARK_LUX_THRESHOLD = 5.0f
    }

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val proximitySensor = sensorManager?.getDefaultSensor(Sensor.TYPE_PROXIMITY)
    private val lightSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_LIGHT)

    private val _isInPocket = MutableStateFlow(false)
    val isInPocket: StateFlow<Boolean> = _isInPocket.asStateFlow()

    private val _isGuardEnabled = MutableStateFlow(true)
    val isGuardEnabled: StateFlow<Boolean> = _isGuardEnabled.asStateFlow()

    private var currentProximityDistance = 100.0f
    private var currentLightLux = 100.0f
    private var proximityMaxRange = 5.0f

    init {
        proximitySensor?.let {
            proximityMaxRange = it.maximumRange
        }
    }

    fun start() {
        if (!_isGuardEnabled.value) return
        try {
            proximitySensor?.let {
                sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
            }
            lightSensor?.let {
                sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
            }
            Log.d(TAG, "PocketGuard sensors registered.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register pocket guard sensors", e)
        }
    }

    fun stop() {
        try {
            sensorManager?.unregisterListener(this)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to unregister pocket guard sensors", e)
        }
    }

    fun toggleGuard(enabled: Boolean) {
        _isGuardEnabled.value = enabled
        if (enabled) {
            start()
        } else {
            stop()
            if (_isInPocket.value) {
                _isInPocket.value = false
                onPocketStateChanged(false)
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return

        when (event.sensor.type) {
            Sensor.TYPE_PROXIMITY -> {
                currentProximityDistance = event.values.getOrNull(0) ?: 100.0f
            }
            Sensor.TYPE_LIGHT -> {
                currentLightLux = event.values.getOrNull(0) ?: 100.0f
            }
        }

        evaluatePocketState()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun evaluatePocketState() {
        // Near condition: proximity distance is less than 3cm or less than maxRange/2
        val isNear = currentProximityDistance < 3.0f || currentProximityDistance < proximityMaxRange
        // Dark condition: ambient light is under 5 lux
        val isDark = currentLightLux < DARK_LUX_THRESHOLD

        val detectedInPocket = isNear && isDark

        if (detectedInPocket != _isInPocket.value) {
            _isInPocket.value = detectedInPocket
            Log.i(TAG, "Pocket status changed -> isInPocket: $detectedInPocket (Near: $isNear, Dark: $isDark)")
            onPocketStateChanged(detectedInPocket)
        }
    }
}
