package com.example

import android.content.Context
import android.telephony.TelephonyManager
import androidx.test.core.app.ApplicationProvider
import com.example.identity.CreatorAttribution
import com.example.telecom.SmartCallManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("ORION", appName)
  }

  @Test
  fun `verify legal creator attribution english`() {
    val response = CreatorAttribution.matchAttribution("Who made you?")
    assertNotNull(response)
    assertEquals(CreatorAttribution.RESPONSE_EN, response)
  }

  @Test
  fun `verify legal creator attribution hindi`() {
    val response = CreatorAttribution.matchAttribution("Tumhe kisne banaya?")
    assertNotNull(response)
    assertEquals(CreatorAttribution.RESPONSE_HI, response)
  }

  @Test
  fun `verify smart call manager ringing state`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val callManager = SmartCallManager.init(context)
    callManager.onCallStateChanged(TelephonyManager.EXTRA_STATE_RINGING, "+919876543210")
    assertEquals(SmartCallManager.CallState.RINGING, callManager.callState.value)
    assertEquals("+919876543210", callManager.incomingNumber.value)

    callManager.onCallStateChanged(TelephonyManager.EXTRA_STATE_IDLE, null)
    assertEquals(SmartCallManager.CallState.IDLE, callManager.callState.value)
  }
}
